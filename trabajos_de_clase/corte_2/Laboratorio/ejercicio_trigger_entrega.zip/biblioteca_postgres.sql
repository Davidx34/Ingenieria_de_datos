-- =========================================================================
-- EJERCICIO TRIGGER - Biblioteca Universitaria "Leer+"
-- Motor: PostgreSQL 14+
-- =========================================================================

-- =========================================================================
-- CONTEXTO EMPRESARIAL
-- =========================================================================
-- La Biblioteca Universitaria "Leer+" presta libros a sus socios. Hoy
-- todo se controla con una hoja de calculo y hay tres problemas:
--   - Nadie sabe con certeza quien tiene libros vencidos, y cada
--     funcionario calcula los dias de retraso a su manera.
--   - Se prestan libros que no hay en estanteria y socios inactivos
--     siguen llevando libros.
--   - Cuando un socio devuelve un libro, a veces el funcionario olvida
--     actualizar el inventario.
-- La direccion decidio migrar a una base de datos e implementar la
-- logica DENTRO de la base de datos, porque el sistema lo usaran el
-- mostrador, una app movil y un tablero de indicadores.

-- =========================================================================
-- REGLAS DE NEGOCIO
-- =========================================================================
-- 1. Un socio inactivo no puede recibir prestamos.
-- 2. Un socio puede tener como maximo 3 prestamos activos (sin devolver).
-- 3. Solo se presta un libro si tiene ejemplares disponibles.
-- 4. Un prestamo dura entre 1 y 30 dias.
-- 5. Al prestar, los ejemplares disponibles bajan en 1; al devolver, suben en 1.
-- 6. Todo prestamo y toda devolucion quedan registrados en historial_prestamos.

DROP DATABASE IF EXISTS biblioteca_db;
CREATE DATABASE biblioteca_db;
\c biblioteca_db

-- ---------------------------------------------------------
-- Tablas
-- ---------------------------------------------------------
CREATE TABLE socios (
    id      INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre  VARCHAR(100) NOT NULL,
    email   VARCHAR(100) NOT NULL UNIQUE,
    activo  BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE libros (
    id                      INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    titulo                  VARCHAR(150) NOT NULL,
    autor                   VARCHAR(100) NOT NULL,
    ejemplares_totales      INT NOT NULL CHECK (ejemplares_totales >= 0),
    ejemplares_disponibles  INT NOT NULL CHECK (ejemplares_disponibles >= 0)
);

CREATE TABLE prestamos (
    id                INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    socio_id          INT NOT NULL REFERENCES socios(id),
    libro_id          INT NOT NULL REFERENCES libros(id),
    fecha_prestamo    DATE NOT NULL,
    fecha_limite      DATE NOT NULL,
    fecha_devolucion  DATE NULL
);

CREATE TABLE historial_prestamos (
    id           INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    prestamo_id  INT NOT NULL REFERENCES prestamos(id),
    accion       VARCHAR(20) NOT NULL,
    detalle      VARCHAR(255),
    usuario      VARCHAR(100) NOT NULL,
    fecha        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- =========================================================================
-- Datos de prueba (fechas relativas a hoy)
-- =========================================================================
INSERT INTO socios (nombre, email, activo) VALUES
('Camila Rojas',   'camila@correo.com',    TRUE),
('Andres Diaz',    'andres@correo.com',    TRUE),
('Valentina Rios', 'valentina@correo.com', FALSE),
('Mateo Castro',   'mateo@correo.com',     TRUE);

INSERT INTO libros (titulo, autor, ejemplares_totales, ejemplares_disponibles) VALUES
('Cien años de soledad',          'Gabriel García Márquez',   3, 2),
('Clean Code',                    'Robert C. Martin',         2, 0),
('Fundamentos de bases de datos', 'Abraham Silberschatz',     4, 3),
('El principito',                 'Antoine de Saint-Exupéry', 2, 2);

INSERT INTO prestamos (socio_id, libro_id, fecha_prestamo, fecha_limite, fecha_devolucion) VALUES
(1, 1, CURRENT_DATE - INTERVAL '40 DAY', CURRENT_DATE - INTERVAL '26 DAY', CURRENT_DATE - INTERVAL '27 DAY'),
(2, 2, CURRENT_DATE - INTERVAL '20 DAY', CURRENT_DATE - INTERVAL  '6 DAY', NULL),
(4, 2, CURRENT_DATE - INTERVAL '18 DAY', CURRENT_DATE - INTERVAL  '4 DAY', NULL),
(4, 1, CURRENT_DATE - INTERVAL  '5 DAY', CURRENT_DATE + INTERVAL  '9 DAY', NULL),
(4, 3, CURRENT_DATE - INTERVAL  '2 DAY', CURRENT_DATE + INTERVAL '12 DAY', NULL);

-- =========================================================================
-- R1 -- VISTA: v_prestamos_vencidos
-- (Postgres: resta de fechas devuelve un entero directamente, sin DATEDIFF)
-- =========================================================================
CREATE OR REPLACE VIEW v_prestamos_vencidos AS
SELECT
    p.id                               AS id_prestamo,
    s.nombre                           AS socio,
    s.email,
    l.titulo,
    p.fecha_limite,
    (CURRENT_DATE - p.fecha_limite)    AS dias_retraso
FROM prestamos p
JOIN socios s ON s.id = p.socio_id
JOIN libros l ON l.id = p.libro_id
WHERE p.fecha_devolucion IS NULL
  AND p.fecha_limite < CURRENT_DATE;

-- Analisis 1: el reporte es una VISTA y no una tabla que se llena cada
-- noche porque debe reflejar el estado real en todo momento (un socio
-- que devuelve un libro a las 9am ya no deberia aparecer como moroso a
-- las 10am); una tabla cacheada por un job nocturno mostraria datos de
-- ayer durante todo el dia siguiente. Se preferiria una VISTA
-- MATERIALIZADA (exclusiva de Postgres entre estos dos motores) si esta
-- consulta se volviera lenta por millones de prestamos historicos y el
-- negocio tolerara ver el reporte con cierto retraso (refrescado cada
-- hora con REFRESH MATERIALIZED VIEW) a cambio de una consulta mucho
-- mas rapida.

-- =========================================================================
-- R2 -- PROCEDIMIENTO ALMACENADO: sp_prestar_libro
-- (Postgres: sin DELIMITER, cuerpo entre $$...$$, LANGUAGE plpgsql;
-- el id generado se obtiene con RETURNING ... INTO)
-- =========================================================================
DROP PROCEDURE IF EXISTS sp_prestar_libro(INT, INT, INT);

CREATE OR REPLACE PROCEDURE sp_prestar_libro(
    IN  p_socio_id    INT,
    IN  p_libro_id    INT,
    IN  p_dias        INT,
    OUT p_prestamo_id INT
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_existe_socio      INT := 0;
    v_activo             BOOLEAN := FALSE;
    v_prestamos_activos  INT := 0;
    v_existe_libro       INT := 0;
    v_disponibles        INT := 0;
BEGIN
    SELECT COUNT(*), COALESCE(MAX(activo::int), 0)::boolean
        INTO v_existe_socio, v_activo
        FROM socios WHERE id = p_socio_id;

    IF v_existe_socio = 0 THEN
        RAISE EXCEPTION 'No existe el socio indicado' USING ERRCODE = '45000';
    END IF;

    -- Regla 1: socio inactivo no puede recibir prestamos
    IF NOT v_activo THEN
        RAISE EXCEPTION 'El socio esta inactivo, no puede recibir prestamos' USING ERRCODE = '45000';
    END IF;

    -- Regla 2: maximo 3 prestamos activos (sin devolver)
    SELECT COUNT(*) INTO v_prestamos_activos
        FROM prestamos
        WHERE socio_id = p_socio_id AND fecha_devolucion IS NULL;

    IF v_prestamos_activos >= 3 THEN
        RAISE EXCEPTION 'El socio ya tiene 3 prestamos activos' USING ERRCODE = '45000';
    END IF;

    SELECT COUNT(*), COALESCE(MAX(ejemplares_disponibles), 0)
        INTO v_existe_libro, v_disponibles
        FROM libros WHERE id = p_libro_id;

    IF v_existe_libro = 0 THEN
        RAISE EXCEPTION 'No existe el libro indicado' USING ERRCODE = '45000';
    END IF;

    -- Regla 3: solo se presta si hay ejemplares disponibles
    IF v_disponibles <= 0 THEN
        RAISE EXCEPTION 'No hay ejemplares disponibles de ese libro' USING ERRCODE = '45000';
    END IF;

    -- Regla 4: un prestamo dura entre 1 y 30 dias
    IF p_dias < 1 OR p_dias > 30 THEN
        RAISE EXCEPTION 'El prestamo debe durar entre 1 y 30 dias' USING ERRCODE = '45000';
    END IF;

    -- Todo valido: crear el prestamo y capturar el id generado
    INSERT INTO prestamos (socio_id, libro_id, fecha_prestamo, fecha_limite, fecha_devolucion)
    VALUES (p_socio_id, p_libro_id, CURRENT_DATE, CURRENT_DATE + p_dias, NULL)
    RETURNING id INTO p_prestamo_id;

    -- Regla 5: descontar un ejemplar disponible
    UPDATE libros SET ejemplares_disponibles = ejemplares_disponibles - 1
        WHERE id = p_libro_id;

    -- Regla 6: registrar la accion en el historial
    INSERT INTO historial_prestamos (prestamo_id, accion, detalle, usuario)
    VALUES (p_prestamo_id, 'PRESTAMO', 'Prestamo creado por ' || p_dias || ' dias', CURRENT_USER);

    -- No hace falta COMMIT/ROLLBACK explicito: si cualquier RAISE
    -- EXCEPTION de arriba se dispara, la llamada completa a CALL se
    -- revierte sola (atomicidad garantizada por el motor).
END;
$$;

-- Analisis 2: el prestamo es un PROCEDIMIENTO y no un trigger BEFORE
-- INSERT sobre prestamos porque necesita VALIDAR varias reglas de
-- negocio relacionadas entre si (socio activo, limite de prestamos,
-- disponibilidad, rango de dias) ANTES de decidir si el INSERT
-- siquiera ocurre, y ademas necesita devolver el id del prestamo creado
-- a quien lo llama. Ventaja del procedimiento: control total del flujo
-- y de que se le devuelve a la aplicacion. Desventaja: solo protege los
-- prestamos que pasan POR el procedimiento; un INSERT directo a
-- prestamos lo evade. Ventaja de un trigger BEFORE INSERT: protegeria
-- cualquier insercion, no solo las que usan el procedimiento.
-- Desventaja: un trigger no puede devolver un id util de forma natural,
-- y las validaciones compuestas quedarian mezcladas con la logica de
-- insercion en vez de separadas con claridad.

-- =========================================================================
-- R3 -- TRIGGER: devolucion automatica
-- (Postgres: primero una FUNCTION que retorna TRIGGER, despues el
-- CREATE TRIGGER que la ejecuta con EXECUTE FUNCTION)
-- =========================================================================
CREATE OR REPLACE FUNCTION fn_prestamos_after_update_devolucion()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF OLD.fecha_devolucion IS NULL AND NEW.fecha_devolucion IS NOT NULL THEN
        UPDATE libros SET ejemplares_disponibles = ejemplares_disponibles + 1
            WHERE id = NEW.libro_id;

        INSERT INTO historial_prestamos (prestamo_id, accion, detalle, usuario)
        VALUES (
            NEW.id,
            'DEVOLUCION',
            'Dias de retraso: ' || GREATEST(NEW.fecha_devolucion - NEW.fecha_limite, 0),
            CURRENT_USER
        );
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_prestamos_after_update_devolucion ON prestamos;
CREATE TRIGGER trg_prestamos_after_update_devolucion
AFTER UPDATE ON prestamos
FOR EACH ROW
EXECUTE FUNCTION fn_prestamos_after_update_devolucion();

-- Analisis 3: la devolucion se automatizo con un TRIGGER y no dentro de
-- un procedimiento sp_devolver_libro porque el UPDATE que marca
-- fecha_devolucion puede venir de tres lugares distintos (el mostrador,
-- la app movil, el tablero de indicadores), y todos deben disparar el
-- mismo efecto sin que cada equipo tenga que acordarse de llamar al
-- procedimiento correcto. El riesgo de NO tener el trigger: un UPDATE
-- directo dejaria el inventario desincronizado y sin rastro en
-- historial_prestamos -- exactamente el problema original del proyecto.

-- =========================================================================
-- RETO OPCIONAL -- TRIGGER BEFORE UPDATE: fecha_devolucion coherente
-- =========================================================================
CREATE OR REPLACE FUNCTION fn_prestamos_before_update_fecha_valida()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF NEW.fecha_devolucion IS NOT NULL AND NEW.fecha_devolucion < NEW.fecha_prestamo THEN
        RAISE EXCEPTION 'La fecha de devolucion no puede ser anterior a la fecha de prestamo' USING ERRCODE = '45000';
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_prestamos_before_update_fecha_valida ON prestamos;
CREATE TRIGGER trg_prestamos_before_update_fecha_valida
BEFORE UPDATE ON prestamos
FOR EACH ROW
EXECUTE FUNCTION fn_prestamos_before_update_fecha_valida();

-- =========================================================================
-- PRUEBAS (ejecutar en este orden)
-- =========================================================================

-- 1) Consultar la vista: 2 filas esperadas (Andres 6 dias, Mateo 4 dias)
SELECT * FROM v_prestamos_vencidos;

-- 2) Prestar a Camila (1) "El principito" (4) por 14 dias -> exito
CALL sp_prestar_libro(1, 4, 14, NULL);
SELECT titulo, ejemplares_disponibles FROM libros WHERE id = 4;

-- 3) Prestar a Valentina (3), inactiva -> error esperado
CALL sp_prestar_libro(3, 1, 7, NULL);

-- 4) Prestar a Camila (1) "Clean Code" (2), agotado -> error esperado
CALL sp_prestar_libro(1, 2, 7, NULL);

-- 5) Prestar a Mateo (4), que ya tiene 3 activos -> error esperado
CALL sp_prestar_libro(4, 3, 7, NULL);

-- 6) Prestar con 0 dias -> error esperado
CALL sp_prestar_libro(1, 3, 0, NULL);

-- 7) Registrar la devolucion del prestamo 2 con fecha de hoy
UPDATE prestamos SET fecha_devolucion = CURRENT_DATE WHERE id = 2;
SELECT titulo, ejemplares_disponibles FROM libros WHERE id = 2;
SELECT * FROM historial_prestamos WHERE prestamo_id = 2 AND accion = 'DEVOLUCION';

-- 8) Consultar la vista otra vez: solo deberia quedar Mateo
SELECT * FROM v_prestamos_vencidos;

-- 9) Repetir el mismo UPDATE del paso 7: no debe cambiar el inventario
--    ni agregar historial (el prestamo ya estaba devuelto)
SELECT ejemplares_disponibles AS disponibles_antes FROM libros WHERE id = 2;
SELECT COUNT(*) AS historial_antes FROM historial_prestamos WHERE prestamo_id = 2 AND accion = 'DEVOLUCION';
UPDATE prestamos SET fecha_devolucion = CURRENT_DATE WHERE id = 2;
SELECT ejemplares_disponibles AS disponibles_despues FROM libros WHERE id = 2;
SELECT COUNT(*) AS historial_despues FROM historial_prestamos WHERE prestamo_id = 2 AND accion = 'DEVOLUCION';

-- =========================================================================
-- PREGUNTAS DE ANALISIS (4 y 5; 1, 2 y 3 ya quedaron junto a cada reto)
-- =========================================================================
-- 4. Que pasaria si dos funcionarios prestan al mismo tiempo el ultimo
--    ejemplar de un libro? Ambas transacciones podrian leer
--    v_disponibles=1 ANTES de que ninguna haga su UPDATE ("lost update"
--    en la lectura), y las dos pasarian la validacion creyendo que
--    alcanza. Lo que evita el peor caso (quedar en -1) es el CHECK
--    (ejemplares_disponibles >= 0) de la tabla libros: la segunda
--    transaccion, al intentar restar sobre un valor que la primera ya
--    dejo en 0, violaria el CHECK y Postgres revertiria automaticamente
--    esa llamada (en Postgres basta con que se lance la excepcion, no
--    hace falta un EXIT HANDLER manual como en MySQL). La linea que
--    cerraria la ventana de raiz seria agregar "SELECT ... FOR UPDATE"
--    al leer v_disponibles.
--
-- 5. Dos cambios que tuve que hacer para portar esto desde MySQL:
--    a) Elimine por completo DELIMITER // ... DELIMITER ; (no existe en
--       Postgres); el cuerpo de la funcion/procedimiento se escribe
--       entre $$ ... $$ con LANGUAGE plpgsql. DATEDIFF(a,b) se
--       reemplazo por la resta directa "a - b"; DATE_ADD(fecha,
--       INTERVAL n DAY) se reemplazo por "fecha + n"; y LAST_INSERT_ID()
--       se reemplazo por "RETURNING id INTO p_prestamo_id" en el mismo
--       INSERT.
--    b) El trigger ya no es un unico CREATE TRIGGER con cuerpo propio:
--       hay que crear primero una FUNCTION que retorne TRIGGER
--       (terminando en RETURN NEW) y despues un CREATE TRIGGER ...
--       EXECUTE FUNCTION que la invoque; y SIGNAL SQLSTATE se
--       reemplazo por RAISE EXCEPTION '...' USING ERRCODE = '45000'.
