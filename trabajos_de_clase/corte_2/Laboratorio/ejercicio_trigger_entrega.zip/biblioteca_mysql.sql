-- =========================================================================
-- EJERCICIO TRIGGER - Biblioteca Universitaria "Leer+"
-- Motor: MySQL 8
-- =========================================================================

-- =========================================================================
-- CONTEXTO EMPRESARIAL
-- =========================================================================
-- La Biblioteca Universitaria "Leer+" presta libros a sus socios. Hoy
-- todo se controla con una hoja de calculo y hay tres problemas:
--   - Nadie sabe con certeza quien tiene libros vencidos, y cada
--     funcionario calcula los dias de retraso a su manera.
--   - Se prestan libros que no hay en estanteria y socios inactivos
--     siguen llevando libros.
--   - Cuando un socio devuelve un libro, a veces el funcionario olvida
--     actualizar el inventario.
-- La direccion decidio migrar a una base de datos e implementar la
-- logica DENTRO de la base de datos, porque el sistema lo usaran el
-- mostrador, una app movil y un tablero de indicadores.

-- =========================================================================
-- REGLAS DE NEGOCIO
-- =========================================================================
-- 1. Un socio inactivo no puede recibir prestamos.
-- 2. Un socio puede tener como maximo 3 prestamos activos (sin devolver).
-- 3. Solo se presta un libro si tiene ejemplares disponibles.
-- 4. Un prestamo dura entre 1 y 30 dias.
-- 5. Al prestar, los ejemplares disponibles bajan en 1; al devolver, suben en 1.
-- 6. Todo prestamo y toda devolucion quedan registrados en historial_prestamos.

DROP DATABASE IF EXISTS biblioteca_db;
CREATE DATABASE biblioteca_db;
USE biblioteca_db;

-- ---------------------------------------------------------
-- Tablas
-- ---------------------------------------------------------
CREATE TABLE socios (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    nombre  VARCHAR(100) NOT NULL,
    email   VARCHAR(100) NOT NULL UNIQUE,
    activo  BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE libros (
    id                      INT AUTO_INCREMENT PRIMARY KEY,
    titulo                  VARCHAR(150) NOT NULL,
    autor                   VARCHAR(100) NOT NULL,
    ejemplares_totales      INT NOT NULL CHECK (ejemplares_totales >= 0),
    ejemplares_disponibles  INT NOT NULL CHECK (ejemplares_disponibles >= 0)
);

CREATE TABLE prestamos (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    socio_id          INT NOT NULL,
    libro_id          INT NOT NULL,
    fecha_prestamo    DATE NOT NULL,
    fecha_limite      DATE NOT NULL,
    fecha_devolucion  DATE NULL,
    CONSTRAINT fk_prestamos_socio FOREIGN KEY (socio_id) REFERENCES socios(id),
    CONSTRAINT fk_prestamos_libro FOREIGN KEY (libro_id) REFERENCES libros(id)
);

CREATE TABLE historial_prestamos (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    prestamo_id  INT NOT NULL,
    accion       VARCHAR(20) NOT NULL,
    detalle      VARCHAR(255),
    usuario      VARCHAR(100) NOT NULL,
    fecha        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_historial_prestamo FOREIGN KEY (prestamo_id) REFERENCES prestamos(id)
);

-- =========================================================================
-- Datos de prueba (fechas relativas a hoy, para que siempre haya
-- prestamos vencidos sin importar cuando se corra el script)
-- =========================================================================
INSERT INTO socios (nombre, email, activo) VALUES
('Camila Rojas',   'camila@correo.com',    TRUE),
('Andres Diaz',    'andres@correo.com',    TRUE),
('Valentina Rios', 'valentina@correo.com', FALSE),
('Mateo Castro',   'mateo@correo.com',     TRUE);

INSERT INTO libros (titulo, autor, ejemplares_totales, ejemplares_disponibles) VALUES
('Cien años de soledad',            'Gabriel García Márquez',  3, 2),
('Clean Code',                      'Robert C. Martin',        2, 0),
('Fundamentos de bases de datos',   'Abraham Silberschatz',    4, 3),
('El principito',                   'Antoine de Saint-Exupéry',2, 2);

INSERT INTO prestamos (socio_id, libro_id, fecha_prestamo, fecha_limite, fecha_devolucion) VALUES
(1, 1, CURRENT_DATE - INTERVAL 40 DAY, CURRENT_DATE - INTERVAL 26 DAY, CURRENT_DATE - INTERVAL 27 DAY),
(2, 2, CURRENT_DATE - INTERVAL 20 DAY, CURRENT_DATE - INTERVAL  6 DAY, NULL),
(4, 2, CURRENT_DATE - INTERVAL 18 DAY, CURRENT_DATE - INTERVAL  4 DAY, NULL),
(4, 1, CURRENT_DATE - INTERVAL  5 DAY, CURRENT_DATE + INTERVAL  9 DAY, NULL),
(4, 3, CURRENT_DATE - INTERVAL  2 DAY, CURRENT_DATE + INTERVAL 12 DAY, NULL);

-- =========================================================================
-- R1 -- VISTA: v_prestamos_vencidos
-- =========================================================================
CREATE OR REPLACE VIEW v_prestamos_vencidos AS
SELECT
    p.id                                  AS id_prestamo,
    s.nombre                              AS socio,
    s.email,
    l.titulo,
    p.fecha_limite,
    DATEDIFF(CURRENT_DATE, p.fecha_limite) AS dias_retraso
FROM prestamos p
JOIN socios s ON s.id = p.socio_id
JOIN libros l ON l.id = p.libro_id
WHERE p.fecha_devolucion IS NULL
  AND p.fecha_limite < CURRENT_DATE;

-- Analisis 1: el reporte es una VISTA y no una tabla que se llena cada
-- noche porque debe reflejar el estado real en todo momento (un socio
-- que devuelve un libro a las 9am ya no deberia aparecer como moroso a
-- las 10am); una tabla cacheada por un job nocturno mostraria datos de
-- ayer durante todo el dia siguiente. Se preferiria una VISTA
-- MATERIALIZADA (Postgres) si esta consulta se volviera lenta por tener
-- millones de prestamos historicos, y el negocio tolerara ver el reporte
-- con cierto retraso (por ejemplo, refrescado cada hora con REFRESH
-- MATERIALIZED VIEW) a cambio de una consulta mucho mas rapida.

-- =========================================================================
-- R2 -- PROCEDIMIENTO ALMACENADO: sp_prestar_libro
-- =========================================================================
DROP PROCEDURE IF EXISTS sp_prestar_libro;

DELIMITER //
CREATE PROCEDURE sp_prestar_libro(
    IN  p_socio_id   INT,
    IN  p_libro_id   INT,
    IN  p_dias       INT,
    OUT p_prestamo_id INT
)
BEGIN
    DECLARE v_existe_socio      INT DEFAULT 0;
    DECLARE v_activo            BOOLEAN DEFAULT FALSE;
    DECLARE v_prestamos_activos INT DEFAULT 0;
    DECLARE v_existe_libro      INT DEFAULT 0;
    DECLARE v_disponibles       INT DEFAULT 0;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    SELECT COUNT(*), COALESCE(MAX(activo), FALSE)
        INTO v_existe_socio, v_activo
        FROM socios WHERE id = p_socio_id;

    IF v_existe_socio = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No existe el socio indicado';
    END IF;

    IF v_activo = FALSE THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El socio esta inactivo, no puede recibir prestamos';
    END IF;

    SELECT COUNT(*) INTO v_prestamos_activos
        FROM prestamos
        WHERE socio_id = p_socio_id AND fecha_devolucion IS NULL;

    IF v_prestamos_activos >= 3 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El socio ya tiene 3 prestamos activos';
    END IF;

    SELECT COUNT(*), COALESCE(MAX(ejemplares_disponibles), 0)
        INTO v_existe_libro, v_disponibles
        FROM libros WHERE id = p_libro_id;

    IF v_existe_libro = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No existe el libro indicado';
    END IF;

    IF v_disponibles <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No hay ejemplares disponibles de ese libro';
    END IF;

    IF p_dias < 1 OR p_dias > 30 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El prestamo debe durar entre 1 y 30 dias';
    END IF;

    INSERT INTO prestamos (socio_id, libro_id, fecha_prestamo, fecha_limite, fecha_devolucion)
    VALUES (p_socio_id, p_libro_id, CURRENT_DATE, DATE_ADD(CURRENT_DATE, INTERVAL p_dias DAY), NULL);

    SET p_prestamo_id = LAST_INSERT_ID();

    UPDATE libros SET ejemplares_disponibles = ejemplares_disponibles - 1
        WHERE id = p_libro_id;

    INSERT INTO historial_prestamos (prestamo_id, accion, detalle, usuario)
    VALUES (p_prestamo_id, 'PRESTAMO', CONCAT('Prestamo creado por ', p_dias, ' dias'), CURRENT_USER());

    COMMIT;
END //
DELIMITER ;

-- Analisis 2: el prestamo es un PROCEDIMIENTO y no un trigger BEFORE
-- INSERT sobre prestamos porque necesita VALIDAR varias reglas de
-- negocio relacionadas entre si (socio activo, limite de prestamos,
-- disponibilidad, rango de dias) ANTES de decidir si el INSERT
-- siquiera ocurre, y ademas necesita devolver el id del prestamo creado
-- a quien lo llama. Ventaja del procedimiento: control total del flujo,
-- de la transaccion y de que se le devuelve a la aplicacion. Desventaja:
-- solo protege los prestamos que pasan POR el procedimiento; un INSERT
-- directo a prestamos lo evade. Ventaja de un trigger BEFORE INSERT:
-- protegeria cualquier insercion, no solo las que usan el procedimiento.
-- Desventaja: un trigger no puede "detenerse con exito y devolver un id
-- util" de forma tan natural, y las validaciones compuestas (como
-- contar los prestamos activos del socio) quedarian mezcladas con la
-- logica de insercion en vez de separadas con claridad.

-- =========================================================================
-- R3 -- TRIGGER: devolucion automatica
-- =========================================================================
DROP TRIGGER IF EXISTS trg_prestamos_after_update_devolucion;

DELIMITER //
CREATE TRIGGER trg_prestamos_after_update_devolucion
AFTER UPDATE ON prestamos
FOR EACH ROW
BEGIN
    IF OLD.fecha_devolucion IS NULL AND NEW.fecha_devolucion IS NOT NULL THEN
        UPDATE libros SET ejemplares_disponibles = ejemplares_disponibles + 1
            WHERE id = NEW.libro_id;

        INSERT INTO historial_prestamos (prestamo_id, accion, detalle, usuario)
        VALUES (
            NEW.id,
            'DEVOLUCION',
            CONCAT('Dias de retraso: ', GREATEST(DATEDIFF(NEW.fecha_devolucion, NEW.fecha_limite), 0)),
            CURRENT_USER()
        );
    END IF;
END //
DELIMITER ;

-- Analisis 3: la devolucion se automatizo con un TRIGGER y no dentro de
-- un procedimiento sp_devolver_libro porque el UPDATE que marca
-- fecha_devolucion puede venir de tres lugares distintos (el mostrador,
-- la app movil, el tablero de indicadores), y todos deben disparar el
-- mismo efecto sin que cada equipo tenga que acordarse de llamar al
-- procedimiento correcto. El riesgo de NO tener el trigger: si alguien
-- hace "UPDATE prestamos SET fecha_devolucion = CURDATE() WHERE id=...;"
-- directo, el libro nunca vuelve a aparecer como disponible en
-- ejemplares_disponibles (el inventario queda desincronizado) y tampoco
-- queda registro de la devolucion en historial_prestamos -- exactamente
-- el problema original que motivo este proyecto.

-- =========================================================================
-- RETO OPCIONAL -- TRIGGER BEFORE UPDATE: fecha_devolucion coherente
-- =========================================================================
DROP TRIGGER IF EXISTS trg_prestamos_before_update_fecha_valida;

DELIMITER //
CREATE TRIGGER trg_prestamos_before_update_fecha_valida
BEFORE UPDATE ON prestamos
FOR EACH ROW
BEGIN
    IF NEW.fecha_devolucion IS NOT NULL AND NEW.fecha_devolucion < NEW.fecha_prestamo THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'La fecha de devolucion no puede ser anterior a la fecha de prestamo';
    END IF;
END //
DELIMITER ;

-- =========================================================================
-- PRUEBAS (ejecutar en este orden)
-- =========================================================================

SELECT * FROM v_prestamos_vencidos;

CALL sp_prestar_libro(1, 4, 14, @id_prestamo);
SELECT @id_prestamo AS id_prestamo_creado;
SELECT titulo, ejemplares_disponibles FROM libros WHERE id = 4;

CALL sp_prestar_libro(3, 1, 7, @id_error1);

CALL sp_prestar_libro(1, 2, 7, @id_error2);

CALL sp_prestar_libro(4, 3, 7, @id_error3);

CALL sp_prestar_libro(1, 3, 0, @id_error4);

UPDATE prestamos SET fecha_devolucion = CURRENT_DATE WHERE id = 2;
SELECT titulo, ejemplares_disponibles FROM libros WHERE id = 2;
SELECT * FROM historial_prestamos WHERE prestamo_id = 2 AND accion = 'DEVOLUCION';

SELECT * FROM v_prestamos_vencidos;

SELECT ejemplares_disponibles AS disponibles_antes FROM libros WHERE id = 2;
SELECT COUNT(*) AS historial_antes FROM historial_prestamos WHERE prestamo_id = 2 AND accion = 'DEVOLUCION';
UPDATE prestamos SET fecha_devolucion = CURRENT_DATE WHERE id = 2;
SELECT ejemplares_disponibles AS disponibles_despues FROM libros WHERE id = 2;
SELECT COUNT(*) AS historial_despues FROM historial_prestamos WHERE prestamo_id = 2 AND accion = 'DEVOLUCION';

-- =========================================================================
-- PREGUNTAS DE ANALISIS (4 y 5; 1, 2 y 3 ya quedaron junto a cada reto)
-- =========================================================================
-- 4. Que pasaria en el procedimiento si dos funcionarios prestan al
--    mismo tiempo el ultimo ejemplar de un libro? Ambas transacciones
--    podrian leer v_disponibles=1 ANTES de que ninguna haga su UPDATE
--    (fenomeno "lost update" en la lectura), y las dos pasarian la
--    validacion "hay disponibles" creyendo que si alcanza. Lo que evita
--    el peor caso (quedar en -1 disponibles) es el CHECK
--    (ejemplares_disponibles >= 0) de la tabla libros: el UPDATE de la
--    segunda transaccion al intentar restar sobre un valor que la
--    primera ya dejo en 0 fallaria el CHECK y se revertiria por el EXIT
--    HANDLER. La linea que realmente cierra la ventana de carrera seria
--    agregar "SELECT ejemplares_disponibles ... FOR UPDATE" al leer
--    v_disponibles, para bloquear la fila del libro desde la lectura y
--    no solo desde la escritura.
--
-- 5. Dos cambios para llevar este codigo a PostgreSQL:
--    a) DELIMITER // ... DELIMITER ; desaparece (el cuerpo va entre
--       $$ ... $$ con LANGUAGE plpgsql); DATEDIFF(a,b) se reemplaza por
--       la resta directa "a - b"; DATE_ADD(CURRENT_DATE, INTERVAL
--       p_dias DAY) se reemplaza por "CURRENT_DATE + p_dias"; y
--       LAST_INSERT_ID() se reemplaza por "RETURNING id INTO
--       p_prestamo_id" en el propio INSERT.
--    b) El trigger ya no es un unico CREATE TRIGGER con cuerpo: hay que
--       crear primero una FUNCTION que retorne TRIGGER (con RETURN NEW
--       al final) y despues un CREATE TRIGGER ... EXECUTE FUNCTION que
--       la invoque; y SIGNAL SQLSTATE se reemplaza por RAISE EXCEPTION
--       '...' USING ERRCODE = '45000'.
