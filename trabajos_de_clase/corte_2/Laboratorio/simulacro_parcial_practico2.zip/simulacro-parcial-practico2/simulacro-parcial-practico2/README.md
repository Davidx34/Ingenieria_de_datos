# Simulacro Parcial Práctico 2 — DronAndes Express

- **Estudiante:** David Catral
- **Curso:** Ingeniería de Datos, corte 2

## De qué trata

DronAndes Express entrega medicamentos, vacunas y otras cargas con drones en Antioquia y Boyacá. Toda su operación vivía en una hoja de cálculo, y eso causó problemas: nadie sabía cuándo fue el último mantenimiento de un dron, los datos de un mismo cliente estaban escritos de varias formas y la carga venía en celdas de texto imposibles de sumar.

En este trabajo diseñé la base de datos relacional que reemplaza esa hoja, cargué los datos del corte del 30 de septiembre de 2026 y resolví las consultas y los objetos programables que piden las distintas áreas (R1 a R13).

## Motores usados

| | Motor | Cliente |
|---|---|---|
| **Principal** | MySQL | MySQL Workbench |
| Otro motor | PostgreSQL | DBeaver |

Hice los dos scripts completos, de R2 a R13, y los probé de principio a fin en cada motor.

## Qué hay en la carpeta

```
simulacro-parcial-practico2/
├── modelo_relacional/MRsustentacion.png
├── mysql/parcial_practico_2_mysql.sql
├── postgresql/parcial_practico_2_postgresql.sql
├── evidencias/
└── README.md
```

**Evidencias**

| Archivos | Qué muestran | Motor |
|---|---|---|
| `evidencia_01a`, `evidencia_01b` | Tablas creadas y estructura de `entregas` | MySQL |
| `evidencia02a`, `evidencia02b` | Tablas creadas y estructura de `entregas` | PostgreSQL |
| `evidencia03` | Resumen de R4.d (clientes, entregas, drones en mantenimiento) | MySQL |
| `evidencia04(7b)`, `evidencia04(8b)` | R7.b y R8.b | MySQL |
| `evidencia05(9a)`, `evidencia05(9D)` | Consultas de R9 | MySQL |
| `evidencia6(10a)`, `evidencia6(11b)` | Vista de R10.a y función de R11 | MySQL |
| `evidencia07a`, `07b`, `07c` | Los tres `update` del trigger y el historial | PostgreSQL |
| `evidencia08a`, `08b`, `08c` | Procedimiento de R13: llamada válida, errores y vista | PostgreSQL |

## Cómo ejecutar los scripts

**MySQL (Workbench).** Abrir el archivo y ejecutarlo completo con el rayo. Conviene activar "Continue on SQL Query Error", porque las dos últimas llamadas de R13 fallan a propósito. El script empieza con `drop database if exists dronandes`, así que se puede repetir sin problema.

**PostgreSQL (DBeaver).**
1. Una sola vez, conectado a `postgres`: `create database dronandes encoding 'UTF8' template template0;`
2. Conectarse a `dronandes`, abrir el script y ejecutarlo completo.

El script empieza con `drop table if exists ... cascade`, así que también se puede repetir. Si el cliente se detiene en los errores esperados de R13, basta con usar "Skip".

## Decisiones de modelado

1. **La relación entre entregas y tipos de carga es muchos a muchos**, porque una entrega puede llevar varios tipos y un tipo aparece en muchas entregas. La resolví con la tabla `cargaentrega`, cuya clave primaria es compuesta: `(identrega, idtipo)`. Elegí esa clave porque la regla RN-08 dice que un tipo de carga no se repite dentro de una entrega, y así la propia clave lo garantiza sin otra restricción. El peso y las unidades dependen de la pareja completa, no de una sola parte.

2. **La supervisión entre pilotos es una relación sobre la misma tabla.** `idsupervisor` apunta a `idpiloto` y admite `null`, porque los jefes de operación no tienen supervisor. La llave foránea se agrega en R3, después de cargar los datos, como pide el enunciado.

3. **Las reglas de negocio quedaron como restricciones cuando se podía.** Puse en `check` el estado de las entregas, la prioridad, la licencia y otros dominios. También agregué que `fechaentrega` solo exista si el estado es `ENTREGADA` (RN-09). La regla RN-05 (la distancia no puede superar la autonomía del dron) no la puse como restricción, porque los datos históricos la violan a propósito (ENT-0019). La validé en el procedimiento de R13 y la audito en la consulta R8.d.

4. **La vista de R10 calcula la carga aparte.** Primero sumo la carga por entrega en una subconsulta y luego la uno con `left join`. Así las entregas sin carga aparecen igual, con 0 tipos y 0 kg, y no se duplican filas.

## Resultados que sirven para revisar

- **R4.b:** 1 fila afectada (el dron DA-COL-01, con 520,5 horas, pasa a mantenimiento).
- **R4.c:** 2 filas eliminadas (ENT-0012 y ENT-0017). ENT-0005 se queda porque sí tiene carga.
- **R4.d:** 13 clientes, 18 entregas y 2 drones en mantenimiento.
- **R8.d:** ENT-0019 supera por 2,0 km la autonomía de su dron.
- **R11:** ENT-0011 vale 148.800, ENT-0013 vale 113.520, ENT-0004 vale 68.856, y la entrega 999 devuelve `null`.
- **R12:** el historial queda con 2 registros (ENT-0018 y ENT-0019). Cambiar solo la calificación de ENT-0011 no registra nada.
- **R13:** ENT-0021 se crea bien. ENT-0022 falla por RN-06 (el dron 4 quedó en mantenimiento en R4.b) y ENT-0023 falla por RN-03 (el piloto 7 tiene licencia A y pide 28 km).

## Lo que aprendí y lo que costó

- **Las diferencias entre motores se notan en cosas pequeñas.** Para los minutos entre dos fechas, MySQL usa `timestampdiff` y PostgreSQL usa `extract(epoch from ...)`. `concat` con un valor nulo devuelve nulo en MySQL, pero en PostgreSQL lo ignora, así que en el organigrama usé `case`. El `like` distingue mayúsculas en PostgreSQL, y por eso comparo contra `lower(email)`.
- **El `where` y el `on` no son lo mismo en un `left join`.** En la productividad de pilotos, si el filtro de estado va en el `where`, los pilotos sin entregas desaparecen. Hay que ponerlo en el `on`.
- **El programa que se usa para ejecutar también importa.** En DBeaver los comandos de psql como `\c` o `\dt` no funcionan, así que dejé consultas normales a `information_schema`. En Workbench, el modo seguro de actualizaciones bloquea el `update` de R4.b y el `delete` de R4.c, y por eso lo desactivo al inicio del script.
- **Un dato que ya existe no se puede crear dos veces.** Si se vuelve a llamar al procedimiento con ENT-0021 sin reiniciar los datos, falla por código duplicado. Es lo correcto: la restricción única está cumpliendo su trabajo.

## Requerimientos incompletos

Ninguno. Todos los requerimientos, de R1 a R13, están hechos y probados en los dos motores.
