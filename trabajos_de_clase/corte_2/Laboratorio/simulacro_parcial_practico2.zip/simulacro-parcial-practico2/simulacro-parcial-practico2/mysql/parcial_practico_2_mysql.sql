-- =====================================================================
-- Simulacro Parcial Práctico 2 — DronAndes Express (Proyecto Cóndor)
-- Motor: MySQL 8.0 (probado también en MariaDB 10.4)
-- Ejecutar de principio a fin sobre un servidor sin la base dronandes.
-- NOTA: las dos últimas llamadas de R13 fallan A PROPÓSITO (validaciones).
--       En el cliente mysql use --force; en Workbench active
--       "Continue on SQL Query Error".
-- =====================================================================

-- R2. Creación de la base de datos
drop database if exists dronandes;
create database dronandes character set utf8mb4 collate utf8mb4_unicode_ci;
use dronandes;
set names utf8mb4;
-- Workbench trae Safe Updates activo: bloquearía el UPDATE de R4.b y el
-- DELETE de R4.c (Error 1175) porque filtran por columnas que no son clave.
set sql_safe_updates = 0;

create table bases (
    idbase           int auto_increment primary key,
    nombre            varchar(60) not null,
    municipio         varchar(60) not null,
    departamento      varchar(40) not null,
    capacidaddrones  int         not null,
    fechaapertura    date        not null,
    constraint ukbasesnombre unique (nombre),
    constraint chkbasescapacidad check (capacidaddrones > 0)
);

create table tiposcarga (
    idtipo        int auto_increment primary key,
    nombre         varchar(40)   not null,
    tarifakg      decimal(10,2) not null,
    requierefrio  boolean       not null default false,
    constraint uktiposcarganombre unique (nombre),
    constraint chktiposcargatarifa check (tarifakg > 0)
);

create table drones (
    iddron            int auto_increment primary key,
    codigoserie       varchar(12)  not null,
    modelo             varchar(40)  not null,
    cargamaxkg       decimal(5,2) not null,   -- su check se agrega en r3.b
    autonomiakm       decimal(5,1) not null,
    estado             varchar(15)  not null default 'ACTIVO',
    horasvuelo        decimal(7,1) not null default 0,
    fechaadquisicion  date         not null,
    idbase            int          not null,
    constraint ukdronescodigoserie unique (codigoserie),
    constraint chkdronesautonomia check (autonomiakm > 0),
    constraint chkdronesestado check (estado in ('ACTIVO','MANTENIMIENTO','RETIRADO')),
    constraint chkdroneshoras check (horasvuelo >= 0),
    constraint fkdronesbase foreign key (idbase) references bases (idbase)
);

create table pilotos (
    idpiloto      int auto_increment primary key,
    documento      varchar(15) not null,
    nombres        varchar(50) not null,
    apellidos      varchar(50) not null,
    email          varchar(80) not null,
    licencia       char(1)     not null,
    fechaingreso  date        not null,
    idsupervisor  int         null,             -- su fk se agrega en r3.c
    idbase        int         not null,
    constraint ukpilotosdocumento unique (documento),
    constraint ukpilotosemail unique (email),
    constraint chkpilotoslicencia check (licencia in ('A','B','C')),
    constraint fkpilotosbase foreign key (idbase) references bases (idbase)
);

create table clientes (
    idcliente      int auto_increment primary key,
    tipo            varchar(12) not null,
    nombre          varchar(80) not null,
    nitdocumento   varchar(15) not null,
    email           varchar(80) null,
    telefono        varchar(15) null,
    municipio       varchar(60) not null,
    fecharegistro  date        not null default (current_date),
    constraint ukclientesnit unique (nitdocumento),
    constraint ukclientesemail unique (email),
    constraint chkclientestipo check (tipo in ('HOSPITAL','FARMACIA','COMERCIO','ONG','PERSONA'))
);

create table entregas (
    identrega         int auto_increment primary key,
    codigo             varchar(10)  not null,
    idcliente         int          not null,
    iddron            int          not null,
    idpiloto          int          not null,
    fechaprogramada   datetime     not null,
    fechaentrega      datetime     null,
    municipiodestino  varchar(60)  not null,
    distanciakm       decimal(5,1) not null,
    prioridad          varchar(8)   not null default 'NORMAL',
    estado             varchar(12)  not null default 'PROGRAMADA',
    calificacion       smallint     null,
    constraint ukentregascodigo unique (codigo),
    constraint chkentregascodigo check (codigo like 'ENT-____'),
    constraint chkentregasdistancia check (distanciakm > 0),
    constraint chkentregasprioridad check (prioridad in ('NORMAL','URGENTE','VITAL')),
    constraint chkentregasestado check (estado in ('PROGRAMADA','EN_VUELO','ENTREGADA','CANCELADA','FALLIDA')),
    constraint chkentregascalificacion check (calificacion between 1 and 5),
    -- RN-09: la fecha real de entrega solo existe si el estado es ENTREGADA
    constraint chkentregasfechaentrega check (fechaentrega is null or estado = 'ENTREGADA'),
    constraint fkentregascliente foreign key (idcliente) references clientes (idcliente),
    constraint fkentregasdron    foreign key (iddron)    references drones (iddron),
    constraint fkentregaspiloto  foreign key (idpiloto)  references pilotos (idpiloto)
);

-- Tabla intermedia N:M entregas <-> tiposcarga.
-- PK compuesta (identrega, idtipo): RN-08 dice que un tipo de carga
-- no se repite dentro de una entrega.
create table cargaentrega (
    identrega  int          not null,
    idtipo     int          not null,
    pesokg     decimal(6,2) not null,
    unidades    int          not null default 1,
    constraint pkcargaentrega primary key (identrega, idtipo),
    constraint chkcargapeso check (pesokg > 0),
    constraint chkcargaunidades check (unidades > 0),
    constraint fkcargaentrega foreign key (identrega) references entregas (identrega),
    constraint fkcargatipo    foreign key (idtipo)    references tiposcarga (idtipo)
);

create table mantenimientos (
    idmantenimiento  int auto_increment primary key,
    iddron           int           not null,
    fecha             date          not null,
    tipo              varchar(12)   not null,
    descripcion       varchar(200)  null,
    costo             decimal(10,2) not null,
    constraint chkmantenimientostipo check (tipo in ('PREVENTIVO','CORRECTIVO')),
    constraint chkmantenimientoscosto check (costo >= 0),
    constraint fkmantenimientosdron foreign key (iddron) references drones (iddron)
);

create table historialentregas (
    idhistorial     int auto_increment primary key,
    identrega       int         not null,
    estadoanterior  varchar(12) not null,
    estadonuevo     varchar(12) not null,
    fechacambio     datetime    not null default current_timestamp,
    constraint fkhistorialentrega foreign key (identrega) references entregas (identrega)
);

-- Evidencia 01
show tables;
describe entregas;

-- =====================================================================
-- DATOS INICIALES — Proyecto Cóndor (DronAndes Express S.A.S.)
-- Corte: 30 de septiembre de 2026, 18:00
-- Script COMÚN para MySQL y PostgreSQL. Ejecutar DESPUÉS del DDL (R2).
-- =====================================================================

insert into bases (idbase, nombre, municipio, departamento, capacidaddrones, fechaapertura) values
(1, 'Base Cóndor',    'Rionegro', 'Antioquia', 6, '2024-02-15'),
(2, 'Base Colibrí',   'Guatapé',  'Antioquia', 4, '2024-08-01'),
(3, 'Base Frailejón', 'Tunja',    'Boyacá',    5, '2025-01-20'),
(4, 'Base Guadua',    'Salento',  'Quindío',   3, '2026-07-01');

insert into tiposcarga (idtipo, nombre, tarifakg, requierefrio) values
(1, 'Vacunas',                 12000, true),
(2, 'Muestras de laboratorio', 10000, true),
(3, 'Medicamentos',             8000, false),
(4, 'Documentos',               5000, false),
(5, 'Repuestos',                4500, false),
(6, 'Alimentos',                3500, false);

insert into drones (iddron, codigoserie, modelo, cargamaxkg, autonomiakm, estado, horasvuelo, fechaadquisicion, idbase) values
(1, 'DA-CX4-01', 'Cóndor X4',    8.00, 45.0, 'ACTIVO',        312.5, '2024-02-20', 1),
(2, 'DA-CX4-02', 'Cóndor X4',    8.00, 45.0, 'ACTIVO',        468.0, '2024-03-10', 1),
(3, 'DA-CX6-01', 'Cóndor X6',   15.00, 60.0, 'ACTIVO',        205.0, '2025-01-15', 1),
(4, 'DA-COL-01', 'Colibrí Mini', 2.50, 25.0, 'ACTIVO',        520.5, '2024-08-05', 2),
(5, 'DA-COL-02', 'Colibrí Mini', 2.50, 25.0, 'MANTENIMIENTO', 610.0, '2024-08-05', 2),
(6, 'DA-ALB-01', 'Albatros H8', 25.00, 90.0, 'ACTIVO',         98.0, '2025-02-01', 3),
(7, 'DA-CX6-02', 'Cóndor X6',   15.00, 60.0, 'ACTIVO',        150.5, '2025-03-12', 3),
(8, 'DA-ALB-02', 'Albatros H8', 25.00, 90.0, 'RETIRADO',      890.0, '2024-05-01', 3);

-- Los supervisores (idsupervisor NULL) se insertan primero.
insert into pilotos (idpiloto, documento, nombres, apellidos, email, licencia, fechaingreso, idsupervisor, idbase) values
(1, '1036600111', 'Laura',   'Restrepo Gil', 'laura.restrepo@dronandes.co', 'C', '2024-02-01', null, 1),
(2, '1049600222', 'Camilo',  'Duarte Rojas', 'camilo.duarte@dronandes.co',  'C', '2025-01-10', null, 3),
(3, '1036600333', 'Mateo',   'Zapata Vélez', 'mateo.zapata@dronandes.co',   'B', '2024-04-15', 1,    1),
(4, '1036600444', 'Sara',    'Montoya Ruiz', 'sara.montoya@dronandes.co',   'B', '2024-08-10', 1,    2),
(5, '1036600555', 'Julián',  'Patiño Cruz',  'julian.patino@dronandes.co',  'A', '2025-06-01', 1,    2),
(6, '1049600666', 'Daniela', 'Suárez León',  'daniela.suarez@dronandes.co', 'B', '2025-02-01', 2,    3),
(7, '1049600777', 'Tomás',   'Becerra Niño', 'tomas.becerra@dronandes.co',  'A', '2026-06-15', 2,    3);

insert into clientes (idcliente, tipo, nombre, nitdocumento, email, telefono, municipio, fecharegistro) values
(1,  'HOSPITAL', 'Hospital San Juan de Dios de Rionegro', '890980000-1', 'compras@hsjdrionegro.org',      '6045310000', 'Rionegro',     '2024-03-01'),
(2,  'FARMACIA', 'Droguería La Esperanza',                '71234567',    'esperanza.drogueria@gmail.com', '3104567890', 'Guatapé',      '2024-09-12'),
(3,  'HOSPITAL', 'E.S.E. Hospital San Rafael de Tunja',   '891800231-6', 'Logistica@HSRTunja.gov.co',     '6087405050', 'Tunja',        '2025-01-25'),
(4,  'ONG',      'Fundación Alas para el Campo',          '900456789-2', 'contacto@alasparaelcampo.org',  null,         'Marinilla',    '2024-11-03'),
(5,  'COMERCIO', 'Repuestos Agrícolas El Arriero',        '900123456-7', null,                            '31245678',   'El Peñol',     '2025-04-18'),
(6,  'PERSONA',  'Mariana Gómez Arango',                  '1040123456',  'mariana.gomez@hotmail.com',     '3157778899', 'Guarne',       '2025-07-07'),
(7,  'FARMACIA', 'Farmacia Botica del Páramo',            '900777888-1', 'boticaparamo@gmail.com',        '3209998877', 'Ventaquemada', '2025-02-14'),
(8,  'COMERCIO', 'Café de Altura Las Nubes',              '901222333-4', 'ventas@cafelasnubes.co',        '3001112233', 'Salento',      '2026-07-20'),
(9,  'PERSONA',  'Jorge Iván Ríos',                       '79888777',    null,                            null,         'Rionegro',     '2026-08-30'),
(10, 'ONG',      'Corporación Montaña Viva',              '900999111-0', 'info@montanaviva.org',          '310555444',  'Sáchica',      '2025-09-01');

insert into entregas (identrega, codigo, idcliente, iddron, idpiloto, fechaprogramada, fechaentrega, municipiodestino, distanciakm, prioridad, estado, calificacion) values
(1,  'ENT-0001', 1,  1, 3, '2026-08-03 08:00:00', '2026-08-03 08:42:00', 'San Vicente',          18.5, 'VITAL',   'ENTREGADA',  5),
(2,  'ENT-0002', 1,  3, 1, '2026-08-05 09:30:00', '2026-08-05 10:20:00', 'Concepción',           32.0, 'VITAL',   'ENTREGADA',  4),
(3,  'ENT-0003', 2,  4, 4, '2026-08-07 14:00:00', '2026-08-07 14:25:00', 'San Rafael',           12.0, 'NORMAL',  'ENTREGADA',  5),
(4,  'ENT-0004', 4,  2, 3, '2026-08-10 07:45:00', '2026-08-10 08:30:00', 'El Carmen de Viboral', 22.4, 'URGENTE', 'ENTREGADA',  3),
(5,  'ENT-0005', 5,  3, 1, '2026-08-12 11:00:00', null,                  'El Peñol',             15.0, 'NORMAL',  'CANCELADA',  null),
(6,  'ENT-0006', 3,  6, 2, '2026-08-14 06:30:00', '2026-08-14 07:40:00', 'Ramiriquí',            48.0, 'VITAL',   'ENTREGADA',  5),
(7,  'ENT-0007', 10, 7, 6, '2026-08-18 10:00:00', '2026-08-18 10:35:00', 'Samacá',               20.5, 'NORMAL',  'ENTREGADA',  4),
(8,  'ENT-0008', 3,  8, 6, '2026-08-20 08:15:00', null,                  'Chíquiza',             35.0, 'URGENTE', 'FALLIDA',    null),
(9,  'ENT-0009', 6,  4, 5, '2026-08-22 16:00:00', '2026-08-22 16:20:00', 'Guarne',                9.5, 'NORMAL',  'ENTREGADA',  2),
(10, 'ENT-0010', 1,  1, 1, '2026-08-25 07:00:00', '2026-08-25 07:50:00', 'Sonsón',               41.0, 'VITAL',   'ENTREGADA',  5),
(11, 'ENT-0011', 10, 6, 2, '2026-08-27 09:00:00', '2026-08-27 10:05:00', 'Sáchica',              52.5, 'URGENTE', 'ENTREGADA',  null),
(12, 'ENT-0012', 2,  5, 4, '2026-08-29 13:00:00', null,                  'Alejandría',           14.0, 'NORMAL',  'CANCELADA',  null),
(13, 'ENT-0013', 4,  2, 1, '2026-09-01 08:00:00', '2026-09-01 08:55:00', 'Granada',              38.0, 'URGENTE', 'ENTREGADA',  4),
(14, 'ENT-0014', 1,  3, 1, '2026-09-03 10:30:00', '2026-09-03 11:15:00', 'Abejorral',            44.0, 'VITAL',   'ENTREGADA',  5),
(15, 'ENT-0015', 7,  7, 6, '2026-09-08 15:00:00', '2026-09-08 15:30:00', 'Turmequé',             17.0, 'NORMAL',  'ENTREGADA',  3),
(16, 'ENT-0016', 3,  6, 2, '2026-09-15 06:00:00', '2026-09-15 07:10:00', 'Miraflores',           58.0, 'VITAL',   'ENTREGADA',  4),
(17, 'ENT-0017', 6,  2, 3, '2026-09-21 17:00:00', null,                  'Guarne',               10.0, 'NORMAL',  'CANCELADA',  null),
(18, 'ENT-0018', 10, 7, 6, '2026-09-30 17:40:00', null,                  'Villa de Leyva',       26.0, 'NORMAL',  'EN_VUELO',   null),
(19, 'ENT-0019', 1,  1, 1, '2026-10-01 07:30:00', null,                  'Nariño',               47.0, 'VITAL',   'PROGRAMADA', null),
(20, 'ENT-0020', 3,  6, 6, '2026-10-02 06:00:00', null,                  'Pesca',                39.0, 'VITAL',   'PROGRAMADA', null);

insert into cargaentrega (identrega, idtipo, pesokg, unidades) values
(1, 1, 3.00, 60),  (1, 3, 2.00, 15),
(2, 2, 1.50, 30),  (2, 3, 4.00, 40),
(3, 3, 1.80, 12),
(4, 3, 3.50, 25),  (4, 4, 0.50, 3),
(5, 5, 6.00, 4),
(6, 1, 5.00, 100), (6, 2, 2.00, 40),
(7, 3, 6.00, 50),
(8, 1, 8.00, 160), (8, 3, 4.00, 30),
(9, 4, 0.80, 5),
(10, 1, 4.00, 80), (10, 2, 1.00, 20), (10, 3, 2.50, 20),
(11, 3, 7.00, 60), (11, 4, 1.00, 6),
(13, 3, 5.00, 40), (13, 5, 2.00, 2),
(14, 1, 6.00, 120), (14, 2, 3.00, 60),
(15, 3, 3.00, 25), (15, 4, 0.30, 2),
(16, 1, 10.00, 200), (16, 3, 8.00, 70),
(18, 3, 4.00, 35),
(19, 1, 3.50, 70),
(20, 2, 2.50, 50), (20, 1, 6.00, 120);

insert into mantenimientos (idmantenimiento, iddron, fecha, tipo, descripcion, costo) values
(1, 2, '2026-03-15', 'PREVENTIVO', 'Cambio de hélices',                          350000),
(2, 4, '2026-04-02', 'PREVENTIVO', 'Calibración de GPS',                         180000),
(3, 5, '2026-09-25', 'CORRECTIVO', 'Falla en motor 3',                          1250000),
(4, 8, '2026-08-21', 'CORRECTIVO', 'Impacto en aterrizaje, evaluación de daños', 2800000),
(5, 1, '2026-06-10', 'PREVENTIVO', 'Revisión general de 300 horas',              420000),
(6, 6, '2026-07-05', 'PREVENTIVO', null,                                         260000),
(7, 5, '2026-05-14', 'PREVENTIVO', 'Cambio de baterías',                         950000),
(8, 2, '2026-09-12', 'CORRECTIVO', 'Sensor de altitud defectuoso',               610000);

-- =====================================================================
-- R3. Ajustes estructurales solicitados por Calidad
-- =====================================================================

-- R3.a  Ampliar clientes.nombre a 120 sin perder NOT NULL
--       (MODIFY redefine la columna completa, por eso se repite NOT NULL)
alter table clientes modify column nombre varchar(120) not null;

-- R3.b  Carga certificada entre 0,5 y 25 kg
alter table drones
    add constraint chkdronescarga check (cargamaxkg between 0.5 and 25);

-- R3.c  Autorreferencia: el supervisor debe ser un piloto existente
alter table pilotos
    add constraint fkpilotossupervisor
    foreign key (idsupervisor) references pilotos (idpiloto);

-- =====================================================================
-- R4. Operaciones de datos (DML)
-- =====================================================================

-- R4.a  Tres clientes nuevos en un solo INSERT (id autogenerado: 11, 12, 13)
insert into clientes (tipo, nombre, nitdocumento, email, telefono, municipio, fecharegistro) values
('FARMACIA', 'Droguería Santa Ana',         '900314159-2', 'santaana@gmail.com',             '3112223344', 'Marinilla', '2026-09-28'),
('PERSONA',  'Esteban Mejía Toro',          '1036987654',  null,                             '3015556677', 'Rionegro',  '2026-09-29'),
('COMERCIO', 'Tienda Naturista Frailejón',  '901555666-3', 'tienda.frailejon@outlook.com',   '3209871234', 'Tunja',     '2026-09-30');

-- R4.b  RN-07: todo dron ACTIVO con más de 500 horas pasa a MANTENIMIENTO
--       Filas afectadas: 1 (DA-COL-01, 520.5 h). DA-COL-02 ya estaba en
--       MANTENIMIENTO y DA-ALB-02 está RETIRADO (no cambia nunca).
update drones
set    estado = 'MANTENIMIENTO'
where  estado = 'ACTIVO'
  and  horasvuelo > 500;

-- R4.c  Eliminar entregas CANCELADA sin ninguna carga registrada
--       Filas eliminadas: 2 (ENT-0012 y ENT-0017). ENT-0005 se conserva
--       porque sí tiene carga.
--       (La subconsulta va sobre cargaentrega, no sobre entregas, así que
--       MySQL no la rechaza con el error 1093.)
delete from entregas
where  estado = 'CANCELADA'
  and  identrega not in (select identrega from cargaentrega);

-- R4.d  Resumen en una sola salida (evidencia 03)
--       Esperado: 13 clientes, 18 entregas, 2 drones en MANTENIMIENTO
select (select count(*) from clientes)                              as totalclientes,
       (select count(*) from entregas)                              as totalentregas,
       (select count(*) from drones where estado = 'MANTENIMIENTO') as dronesmantenimiento;

-- =====================================================================
-- R5. Tablero de control operativo
-- =====================================================================

-- R5.a  Entregas de media distancia con prioridad alta
select codigo, municipiodestino, distanciakm, prioridad
from   entregas
where  estado = 'ENTREGADA'
  and  distanciakm between 20 and 45
  and  prioridad in ('VITAL', 'URGENTE')
order by distanciakm desc;

-- R5.b.1  Entregas cerradas sin entrega efectiva
select codigo, estado, fechaprogramada
from   entregas
where  estado not in ('PROGRAMADA', 'EN_VUELO', 'ENTREGADA')
  and  fechaentrega is null
order by codigo;

-- R5.b.2  Entregas con fecha de entrega pero sin calificación
select codigo, fechaentrega
from   entregas
where  fechaentrega is not null
  and  calificacion is null;

-- R5.c  Drones para campaña de carga pesada
select codigoserie, modelo, cargamaxkg, horasvuelo, autonomiakm, estado
from   drones
where  estado != 'RETIRADO'
  and  ((cargamaxkg >= 8 and horasvuelo < 400) or autonomiakm > 80)
order by codigoserie asc;

-- R5.d  Pilotos con licencia distinta de A que ingresaron hasta el 2025-02-01
select nombres, apellidos, licencia, fechaingreso
from   pilotos
where  not licencia = 'A'
  and  fechaingreso <= '2025-02-01'
order by fechaingreso asc;

-- =====================================================================
-- R6. Directorio comercial y calidad de datos
-- =====================================================================

-- R6.a  Clientes con teléfono inválido (RN-13: exactamente 10 dígitos)
select upper(nombre)                       as cliente,
       municipio,
       coalesce(telefono, 'SIN TELÉFONO')  as telefono,
       length(telefono)                    as digitos
from   clientes
where  telefono is null
   or  length(telefono) <> 10
order by nombre asc;

-- R6.b  Clientes con correo corporativo (no gratuito)
select nombre,
       lower(email)                                as correo,
       concat(nombre, ' <', lower(email), '>')     as contacto
from   clientes
where  email is not null
  and  lower(email) not like '%@gmail.com'
  and  lower(email) not like '%@hotmail.com'
  and  lower(email) not like '%@outlook.com'
order by nombre;

-- R6.c  Drones Cóndor con serie DA-CX?-NN y % de vida útil (RN-12: 1.000 h)
select codigoserie,
       upper(modelo)                        as modelo,
       horasvuelo,
       round(horasvuelo / 1000 * 100, 1)   as pctvidautil
from   drones
where  codigoserie like 'DA-CX_-__'
order by horasvuelo desc;

-- =====================================================================
-- R7. Indicadores de gestión
-- =====================================================================

-- R7.a  Indicadores por tipo de carga (solo entregas ENTREGADA)
select tc.nombre                         as tipocarga,
       count(distinct ce.identrega)     as numentregas,
       sum(ce.pesokg)                   as kgtotales,
       round(avg(ce.pesokg), 2)         as kgpromedio,
       min(ce.pesokg)                   as kgminimo,
       max(ce.pesokg)                   as kgmaximo
from   tiposcarga tc
inner join cargaentrega ce on ce.idtipo   = tc.idtipo
inner join entregas e       on e.identrega = ce.identrega
where  e.estado = 'ENTREGADA'
group by tc.idtipo, tc.nombre
order by kgtotales desc;

-- R7.b  Clientes estrella: >= 2 entregas ENTREGADA y promedio >= 4
--       (AVG ignora las calificaciones NULL, COUNT(*) sí cuenta la entrega)
select c.nombre                         as cliente,
       count(*)                         as entregasrealizadas,
       round(avg(e.calificacion), 2)    as calificacionpromedio
from   clientes c
inner join entregas e on e.idcliente = c.idcliente
where  e.estado = 'ENTREGADA'
group by c.idcliente, c.nombre
having count(*) >= 2
   and avg(e.calificacion) >= 4
order by calificacionpromedio desc, cliente asc;

-- =====================================================================
-- R8. Consultas multitabla
-- =====================================================================

-- R8.a  Hoja de vuelo de entregas VITAL entregadas (solo INNER JOIN)
select e.codigo,
       c.nombre                                               as cliente,
       concat(p.nombres, ' ', p.apellidos)                    as piloto,
       d.codigoserie                                         as dron,
       b.nombre                                               as base,
       timestampdiff(minute, e.fechaprogramada, e.fechaentrega) as minutosvuelo
from   entregas e
inner join clientes c on c.idcliente = e.idcliente
inner join pilotos  p on p.idpiloto  = e.idpiloto
inner join drones   d on d.iddron    = e.iddron
inner join bases    b on b.idbase    = d.idbase
where  e.prioridad = 'VITAL'
  and  e.estado    = 'ENTREGADA'
order by e.fechaprogramada asc;

-- R8.b  Productividad de pilotos (los que no tienen entregas aparecen con 0)
--       El filtro de estado va en el ON para no perder los pilotos sin entregas.
select concat(p.nombres, ' ', p.apellidos)  as piloto,
       p.licencia,
       count(e.identrega)                  as entregasrealizadas
from   pilotos p
left join entregas e on e.idpiloto = p.idpiloto
                    and e.estado    = 'ENTREGADA'
group by p.idpiloto, p.nombres, p.apellidos, p.licencia
order by entregasrealizadas desc, piloto asc;

-- R8.c  Organigrama (relación recursiva con LEFT JOIN de pilotos consigo misma)
select concat(p.nombres, ' ', p.apellidos)  as piloto,
       p.licencia,
       case when s.idpiloto is null then 'DIRECCIÓN DE OPERACIONES'
            else concat(s.nombres, ' ', s.apellidos)
       end                                  as supervisor
from   pilotos p
left join pilotos s on s.idpiloto = p.idsupervisor
order by supervisor, piloto;

-- R8.d  Auditoría RN-05: entregas PROGRAMADA que superan la autonomía del dron
select e.codigo,
       c.nombre                          as cliente,
       d.codigoserie                    as dron,
       e.distanciakm,
       d.autonomiakm,
       e.distanciakm - d.autonomiakm   as excesokm
from   entregas e
inner join clientes c on c.idcliente = e.idcliente
inner join drones   d on d.iddron    = e.iddron
where  e.estado = 'PROGRAMADA'
  and  e.distanciakm > d.autonomiakm
order by e.codigo;

-- =====================================================================
-- R9. Subconsultas
-- =====================================================================

-- R9.a  Entregas ENTREGADA por encima del promedio de distancia de las ENTREGADA
select codigo, municipiodestino, distanciakm
from   entregas
where  estado = 'ENTREGADA'
  and  distanciakm > (select avg(distanciakm)
                       from   entregas
                       where  estado = 'ENTREGADA')
order by distanciakm desc;

-- R9.b  Clientes que nunca han tenido una entrega
select nombre, tipo, municipio, fecharegistro
from   clientes
where  idcliente not in (select idcliente from entregas)
order by fecharegistro, nombre;

-- R9.c  Drones con más horas que el promedio de su base (correlacionada)
select d.codigoserie,
       b.nombre        as base,
       d.horasvuelo
from   drones d
inner join bases b on b.idbase = d.idbase
where  d.horasvuelo > (select avg(d2.horasvuelo)
                        from   drones d2
                        where  d2.idbase = d.idbase)
order by base, d.codigoserie;

-- R9.d  Drones no retirados que nunca han tenido mantenimiento
select d.codigoserie, d.modelo, d.estado
from   drones d
where  d.estado <> 'RETIRADO'
  and  not exists (select 1
                   from   mantenimientos m
                   where  m.iddron = d.iddron)
order by d.codigoserie;

-- =====================================================================
-- R10. Vista e índices
-- =====================================================================

-- R10.a  Vista con una fila por entrega. La carga se agrega antes en una
--        tabla derivada y se une con LEFT JOIN para no perder las entregas
--        sin carga (tiposcarga = 0, pesototalkg = 0).
drop view if exists vwtableroentregas;
create view vwtableroentregas as
select e.codigo,
       e.fechaprogramada,
       c.nombre                              as cliente,
       c.tipo                                as tipocliente,
       e.municipiodestino,
       d.codigoserie                        as dron,
       concat(p.nombres, ' ', p.apellidos)   as piloto,
       e.prioridad,
       e.estado,
       coalesce(ca.tiposcarga, 0)           as tiposcarga,
       coalesce(ca.pesototalkg, 0)         as pesototalkg
from   entregas e
inner join clientes c on c.idcliente = e.idcliente
inner join drones   d on d.iddron    = e.iddron
inner join pilotos  p on p.idpiloto  = e.idpiloto
left join (select identrega,
                  count(*)     as tiposcarga,
                  sum(pesokg) as pesototalkg
           from   cargaentrega
           group by identrega) ca on ca.identrega = e.identrega;

-- Prueba de la vista (evidencia 06)
select *
from   vwtableroentregas
where  estado in ('PROGRAMADA', 'EN_VUELO')
order by fechaprogramada;

-- R10.b  Índices
-- idxentregasestadofecha: la búsqueda filtra por igualdad en estado y por
-- rango en fechaprogramada; con la columna de igualdad primero, el motor
-- ubica el estado y recorre solo el tramo de fechas pedido.
create index idxentregasestadofecha on entregas (estado, fechaprogramada);

-- idxclientestipomunicipio: ambas columnas se filtran por igualdad;
-- el índice compuesto resuelve la búsqueda tipo + municipio y también
-- las búsquedas solo por tipo (prefijo izquierdo).
create index idxclientestipomunicipio on clientes (tipo, municipio);

show index from entregas where key_name like 'idx%';
show index from clientes where key_name like 'idx%';

-- =====================================================================
-- R11. Función almacenada
-- =====================================================================

-- RN-10: valor = SUM(pesokg * tarifakg) + distanciakm * 1200;
--        URGENTE lleva recargo del 20 %. NULL si la entrega no existe.
drop function if exists fnvalorentrega;
delimiter $$
create function fnvalorentrega(pidentrega int)
returns decimal(14,2)
reads sql data
begin
    declare vdistancia  decimal(5,1);
    declare vprioridad  varchar(8);
    declare vcarga      decimal(14,2);
    declare vtotal      decimal(14,2);

    if not exists (select 1 from entregas where identrega = pidentrega) then
        return null;
    end if;

    select distanciakm, prioridad
      into vdistancia, vprioridad
      from entregas
     where identrega = pidentrega;

    select coalesce(sum(ce.pesokg * tc.tarifakg), 0)
      into vcarga
      from cargaentrega ce
      inner join tiposcarga tc on tc.idtipo = ce.idtipo
     where ce.identrega = pidentrega;

    set vtotal = vcarga + vdistancia * 1200;

    if vprioridad = 'URGENTE' then
        set vtotal = vtotal * 1.20;
    end if;

    return round(vtotal, 2);
end$$
delimiter ;

-- R11.b (1)  Entregas ENTREGADA y URGENTE con su valor (evidencia 06)
select codigo, prioridad, fnvalorentrega(identrega) as valorcop
from   entregas
where  estado = 'ENTREGADA'
  and  prioridad = 'URGENTE'
order by valorcop desc;

-- R11.b (2)  Entrega inexistente -> NULL
select fnvalorentrega(999) as valorcop;

-- =====================================================================
-- R12. Trigger de auditoría
-- =====================================================================

drop trigger if exists trgentregasestado;
delimiter $$
create trigger trgentregasestado
before update on entregas
for each row
begin
    if new.estado <> old.estado then
        -- (1) Si pasa a ENTREGADA sin fecha real, se le asigna la actual
        if new.estado = 'ENTREGADA' and new.fechaentrega is null then
            set new.fechaentrega = now();
        end if;
        -- (2) Registro de auditoría (RN-11)
        insert into historialentregas (identrega, estadoanterior, estadonuevo)
        values (old.identrega, old.estado, new.estado);
    end if;
end$$
delimiter ;

-- Prueba (evidencia 07): dos cambios reales de estado y uno sin cambio
update entregas set estado = 'ENTREGADA', calificacion = 5 where codigo = 'ENT-0018';
update entregas set estado = 'CANCELADA' where codigo = 'ENT-0019';
update entregas set calificacion = 4 where codigo = 'ENT-0011';

-- Esperado: 2 registros en el historial (ENT-0018 y ENT-0019); ENT-0011 no.
select h.idhistorial, e.codigo, h.estadoanterior, h.estadonuevo, h.fechacambio
from   historialentregas h
inner join entregas e on e.identrega = h.identrega
order by h.idhistorial;

select codigo, estado, fechaentrega, calificacion
from   entregas
where  codigo in ('ENT-0018', 'ENT-0019', 'ENT-0011')
order by codigo;

-- =====================================================================
-- R13. Procedimiento almacenado
-- =====================================================================

drop procedure if exists spprogramarentrega;
delimiter $$
create procedure spprogramarentrega(
    in pcodigo      varchar(10),
    in pidcliente  int,
    in piddron     int,
    in pidpiloto   int,
    in pfecha       datetime,
    in pmunicipio   varchar(60),
    in pdistancia   decimal(5,1),
    in pprioridad   varchar(8)
)
begin
    declare vestado     varchar(15);
    declare vautonomia  decimal(5,1);
    declare vlicencia   char(1);
    declare vmsg        varchar(255);

    -- 1. El dron y el piloto deben existir
    if not exists (select 1 from drones where iddron = piddron) then
        set vmsg = concat('El dron ', piddron, ' no existe');
        signal sqlstate '45000' set message_text = vmsg;
    end if;
    if not exists (select 1 from pilotos where idpiloto = pidpiloto) then
        set vmsg = concat('El piloto ', pidpiloto, ' no existe');
        signal sqlstate '45000' set message_text = vmsg;
    end if;

    select estado, autonomiakm into vestado, vautonomia
      from drones where iddron = piddron;
    select licencia into vlicencia
      from pilotos where idpiloto = pidpiloto;

    -- 2. RN-06: solo un dron ACTIVO recibe entregas nuevas
    if vestado <> 'ACTIVO' then
        set vmsg = concat('RN-06: el dron ', piddron, ' está en estado ', vestado,
                           ' y solo un dron ACTIVO puede recibir entregas');
        signal sqlstate '45000' set message_text = vmsg;
    end if;

    -- 3. RN-05: la distancia no puede superar la autonomía del dron
    if pdistancia > vautonomia then
        set vmsg = concat('RN-05: la distancia (', pdistancia, ' km) supera la autonomía del dron (',
                           vautonomia, ' km)');
        signal sqlstate '45000' set message_text = vmsg;
    end if;

    -- 4. RN-03: A hasta 20 km, B hasta 40 km, C sin límite
    if (vlicencia = 'A' and pdistancia > 20) or (vlicencia = 'B' and pdistancia > 40) then
        set vmsg = concat('RN-03: la licencia ', vlicencia, ' del piloto ', pidpiloto,
                           ' no permite volar ', pdistancia, ' km');
        signal sqlstate '45000' set message_text = vmsg;
    end if;

    -- Todo válido: el estado queda PROGRAMADA por el DEFAULT
    insert into entregas (codigo, idcliente, iddron, idpiloto, fechaprogramada,
                          municipiodestino, distanciakm, prioridad)
    values (pcodigo, pidcliente, piddron, pidpiloto, pfecha,
            pmunicipio, pdistancia, pprioridad);

    select concat('Entrega ', pcodigo, ' programada con identrega = ', last_insert_id()) as mensaje;
end$$
delimiter ;

-- Prueba (evidencia 08)
-- Llamada válida: dron 3 ACTIVO (60 km), piloto 3 licencia B (40 km), 16 km
call spprogramarentrega('ENT-0021', 11, 3, 3, '2026-10-03 10:00:00', 'Marinilla', 16.0, 'URGENTE');

select * from vwtableroentregas where codigo = 'ENT-0021';

-- Error esperado RN-06: el dron 4 pasó a MANTENIMIENTO en R4.b
call spprogramarentrega('ENT-0022', 6, 4, 4, '2026-10-03 11:00:00', 'Guarne', 9.0, 'NORMAL');

-- Error esperado RN-03: el piloto 7 tiene licencia A (máx. 20 km) y pide 28 km
call spprogramarentrega('ENT-0023', 2, 7, 7, '2026-10-04 08:00:00', 'Arcabuco', 28.0, 'NORMAL');
