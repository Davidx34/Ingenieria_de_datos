-- =========================================================================
-- TRAZACAFE - LABORATORIO DDL Y DML
-- Motor: PostgreSQL 14+
-- Ejecutar con: psql -U postgres -f trazacafe_postgres.sql
-- (arranca conectado a la base por defecto, luego crea y se conecta a
-- trazacafe con \c)
-- =========================================================================

-- =========================================================================
-- RETO 1. El plano de la finca (diseño) — 10 pts
-- =========================================================================
-- Ver 01_modelo_trazacafe.md (mismo modelo relacional que la version
-- MySQL: es el mismo diseño, aplicado en dos motores distintos).
--
-- Reflexion: el requerimiento 6 se resuelve con ON DELETE RESTRICT en
-- las FK Lotes.fincaId y Pedidos.clienteId: el motor impide borrar
-- fisicamente una finca o un cliente que ya tiene Lotes o Pedidos
-- asociados. Para retirar un caficultor sin perder el historial se usa
-- una baja logica (columna Fincas.activa, agregada en el reto 8).

-- =========================================================================
-- RETO 2. Los cimientos (CREATE DATABASE / SCHEMA / TABLE) — 10 pts
-- =========================================================================
DROP DATABASE IF EXISTS trazacafe;
CREATE DATABASE trazacafe;
\c trazacafe

CREATE SCHEMA IF NOT EXISTS operacion;
SET search_path TO operacion, public;

-- Orden de creacion: primero las tablas que no dependen de nadie.

CREATE TABLE "Fincas" (
    "idFinca"     INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    "nombre"       VARCHAR(100) NOT NULL,
    "caficultor"   VARCHAR(100) NOT NULL,
    "municipio"    VARCHAR(80)  NOT NULL,
    "departamento" VARCHAR(80)  NOT NULL,
    "altitudM"    INT NOT NULL
);

CREATE TABLE "Clientes" (
    "idCliente" INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    "nombre"     VARCHAR(100) NOT NULL
);

CREATE TABLE "Lotes" (
    "idLote"      INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    "codigoLote"  VARCHAR(20) NOT NULL,
    "fincaId"     INT NOT NULL,
    "variedad"     VARCHAR(30) NOT NULL,
    "proceso"      VARCHAR(10) NOT NULL CHECK ("proceso" IN ('lavado','honey','natural')),
    -- Alternativa mas estricta: CREATE TYPE procesoCafe AS ENUM ('lavado','honey','natural');
    "fechaCosecha" DATE NOT NULL,
    "kilos"        NUMERIC(7,2) NOT NULL,
    -- ON DELETE RESTRICT: protege el requerimiento 6 (no perder
    -- historial de venta si el lote pertenece a una finca "retirada").
    CONSTRAINT fk_lote_finca FOREIGN KEY ("fincaId")
        REFERENCES "Fincas"("idFinca") ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE "Cataciones" (
    "idCatacion"   INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    "loteId"       INT NOT NULL,
    "catador"       VARCHAR(80) NOT NULL,
    "puntajeSca"   NUMERIC(5,2) NOT NULL,
    "fechaCatacion" DATE NOT NULL,
    CONSTRAINT fk_catacion_lote FOREIGN KEY ("loteId")
        REFERENCES "Lotes"("idLote") ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE "Tostiones" (
    "idTostion"     INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    "loteId"        INT NOT NULL,
    "fechaTostion"  DATE NOT NULL,
    "kilosEntrada"  NUMERIC(7,2) NOT NULL,
    "kilosSalida"   NUMERIC(7,2) NOT NULL,
    "perfil"         VARCHAR(10) NOT NULL CHECK ("perfil" IN ('claro','medio','oscuro')),
    CONSTRAINT fk_tostion_lote FOREIGN KEY ("loteId")
        REFERENCES "Lotes"("idLote") ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE "Pedidos" (
    "idPedido"    INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    "clienteId"   INT NOT NULL,
    "fechaPedido" DATE NOT NULL DEFAULT CURRENT_DATE,
    "estado"       VARCHAR(20) NOT NULL DEFAULT 'pendiente',
    CONSTRAINT fk_pedido_cliente FOREIGN KEY ("clienteId")
        REFERENCES "Clientes"("idCliente") ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE "LineasPedido" (
    "idLinea"   INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    "pedidoId"  INT NOT NULL,
    "tostionId" INT NOT NULL,
    "kilos"      NUMERIC(7,2) NOT NULL,
    "precioKg"  NUMERIC(10,2) NOT NULL,
    -- ON DELETE CASCADE: si se anula la cabecera, sus lineas no
    -- tienen sentido por si solas.
    CONSTRAINT fk_linea_pedido FOREIGN KEY ("pedidoId")
        REFERENCES "Pedidos"("idPedido") ON UPDATE CASCADE ON DELETE CASCADE,
    -- ON DELETE RESTRICT: no perder que se vendio de esa tostion.
    CONSTRAINT fk_linea_tostion FOREIGN KEY ("tostionId")
        REFERENCES "Tostiones"("idTostion") ON UPDATE CASCADE ON DELETE RESTRICT
);

SELECT version();
\d operacion."Lotes"

-- Reflexion: si se crea primero "Lotes" y despues "Fincas", PostgreSQL
-- rechaza el CREATE TABLE de Lotes con "ERROR: relation "Fincas" does
-- not exist" porque la FK fincaId no puede apuntar a una tabla que
-- todavia no existe.

-- =========================================================================
-- RETO 3. Los guardianes de la calidad (CHECK, UNIQUE, Prueba de fuego) — 10 pts
-- =========================================================================
ALTER TABLE "Fincas"
    ADD CONSTRAINT chk_finca_altitud CHECK ("altitudM" BETWEEN 800 AND 2500);

ALTER TABLE "Lotes"
    ADD CONSTRAINT uq_lote_codigo UNIQUE ("codigoLote");

ALTER TABLE "Cataciones"
    ADD CONSTRAINT chk_catacion_puntaje CHECK ("puntajeSca" BETWEEN 0 AND 100);

ALTER TABLE "Tostiones"
    ADD CONSTRAINT chk_tostion_kilos CHECK ("kilosSalida" <= "kilosEntrada");

ALTER TABLE "Pedidos"
    ADD CONSTRAINT chk_pedido_estado
        CHECK ("estado" IN ('pendiente','confirmado','enviado','entregado','cancelado'));

-- Semilla de Prueba (finca y lote "de Prueba", usados otra vez en el
-- reto 8 para el DELETE cruzado y la baja logica).
INSERT INTO "Fincas" ("nombre", "caficultor", "municipio", "departamento", "altitudM")
VALUES ('Finca Prueba QA', 'Datos de Prueba', 'Pitalito', 'Huila', 1200);

INSERT INTO "Lotes" ("codigoLote", "fincaId", "variedad", "proceso", "fechaCosecha", "kilos")
VALUES ('TEST-0000', (SELECT "idFinca" FROM "Fincas" WHERE "nombre"='Finca Prueba QA'), 'Caturra', 'lavado', '2026-01-01', 10.00);

-- --- Prueba de fuego ---

-- (a) altitud fuera de rango -> viola chk_finca_altitud
INSERT INTO "Fincas" ("nombre", "caficultor", "municipio", "departamento", "altitudM")
VALUES ('Finca Altitud Invalida', 'N/A', 'N/A', 'N/A', 100);
-- Error esperado (PostgreSQL):
-- ERROR:  new row for relation "Fincas" violates check constraint "chk_finca_altitud"

-- (b) codigoLote repetido -> viola uq_lote_codigo
INSERT INTO "Lotes" ("codigoLote", "fincaId", "variedad", "proceso", "fechaCosecha", "kilos")
VALUES ('TEST-0000', 1, 'Castillo', 'honey', '2026-01-02', 20.00);
-- Error esperado:
-- ERROR:  duplicate key value violates unique constraint "uq_lote_codigo"

-- (c) puntaje SCA fuera de [0,100] -> viola chk_catacion_puntaje
INSERT INTO "Cataciones" ("loteId", "catador", "puntajeSca", "fechaCatacion")
VALUES (1, 'Catador Invalido', 150.00, '2026-01-03');
-- Error esperado:
-- ERROR:  new row for relation "Cataciones" violates check constraint "chk_catacion_puntaje"

-- (d) kilosSalida > kilosEntrada -> viola chk_tostion_kilos
INSERT INTO "Tostiones" ("loteId", "fechaTostion", "kilosEntrada", "kilosSalida", "perfil")
VALUES (1, '2026-01-04', 5.00, 9.00, 'medio');
-- Error esperado:
-- ERROR:  new row for relation "Tostiones" violates check constraint "chk_tostion_kilos"

-- Reflexion: la regla de que el puntaje PROMEDIO de un lote (agregado
-- entre varias filas de Cataciones) determine si es "cafe de
-- especialidad" no se puede expresar con un CHECK, porque un CHECK
-- solo ve columnas de la MISMA fila en el momento del INSERT/UPDATE:
-- no puede mirar otras filas ni otras tablas. Eso exige un TRIGGER o
-- logica de aplicacion (ver reto 5, donde se hace con GROUP BY).

-- =========================================================================
-- RETO 4. Llego el correo de Berlin (ALTER TABLE) — 10 pts
-- =========================================================================

-- 1) pais en Clientes, obligatorio, default 'Colombia'
ALTER TABLE "Clientes"
    ADD COLUMN "pais" VARCHAR(60) NOT NULL DEFAULT 'Colombia';

-- 2) huella de carbono, nula, nunca negativa
ALTER TABLE "Tostiones"
    ADD COLUMN "huellaCarbonoKg" NUMERIC(8,2) NULL;
ALTER TABLE "Tostiones"
    ADD CONSTRAINT chk_tostion_huella CHECK ("huellaCarbonoKg" IS NULL OR "huellaCarbonoKg" >= 0);

-- 3) ampliar precision de todas las columnas de kilos: (7,2) -> (10,2)
ALTER TABLE "Lotes"         ALTER COLUMN "kilos"         TYPE NUMERIC(10,2);
ALTER TABLE "Tostiones"     ALTER COLUMN "kilosEntrada" TYPE NUMERIC(10,2);
ALTER TABLE "Tostiones"     ALTER COLUMN "kilosSalida"  TYPE NUMERIC(10,2);
ALTER TABLE "LineasPedido" ALTER COLUMN "kilos"         TYPE NUMERIC(10,2);

-- 4) Certificaciones N:M
CREATE TABLE "Certificaciones" (
    "idCertificacion" INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    "nombre"           VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE "FincaCertificacion" (
    "fincaId"         INT NOT NULL,
    "certificacionId" INT NOT NULL,
    "fechaObtencion"  DATE NOT NULL,
    PRIMARY KEY ("fincaId", "certificacionId"),
    CONSTRAINT fk_fc_finca FOREIGN KEY ("fincaId")
        REFERENCES "Fincas"("idFinca") ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_fc_certificacion FOREIGN KEY ("certificacionId")
        REFERENCES "Certificaciones"("idCertificacion") ON UPDATE CASCADE ON DELETE RESTRICT
);

-- 5) renombrar "kilos" (ambiguo) a "kilosCosechados" en Lotes
ALTER TABLE "Lotes" RENAME COLUMN "kilos" TO "kilosCosechados";

\d operacion."Lotes"
\d operacion."Tostiones"

-- Reflexion: borrar y recrear una tabla en produccion es peligroso
-- porque se pierden los datos y el historial, se rompen o disparan en
-- cascada las FK de otras tablas que la referencian, el servicio queda
-- sin esa tabla mientras no existe, y cualquier vista/indice/permiso
-- asociado desaparece. ALTER TABLE cambia la estructura sin sacrificar
-- los datos ni los vinculos existentes.

-- =========================================================================
-- RETO 5. La primera cosecha (INSERT masivos) — 10 pts
-- =========================================================================
-- La Finca Prueba QA y el Lote TEST-0000 ya se cargaron en el reto 3.

INSERT INTO "Fincas" ("nombre", "caficultor", "municipio", "departamento", "altitudM") VALUES
('Finca La Esperanza', 'Jorge Ivan Bolanos',  'Pitalito', 'Huila',   1750),
('Finca El Mirador',   'Marta Elena Rios',    'Salento',  'Quindio', 1900),
('Finca Buenavista',   'Camilo Andres Munoz', 'Buesaco',  'Narino',  2100);

INSERT INTO "Lotes" ("codigoLote", "fincaId", "variedad", "proceso", "fechaCosecha", "kilosCosechados") VALUES
('HUI-2026-014', (SELECT "idFinca" FROM "Fincas" WHERE "nombre"='Finca La Esperanza'), 'Caturra',  'lavado',  '2026-03-02', 320.50),
('HUI-2026-015', (SELECT "idFinca" FROM "Fincas" WHERE "nombre"='Finca La Esperanza'), 'Castillo', 'honey',   '2026-02-18', 410.00),
('HUI-2026-016', (SELECT "idFinca" FROM "Fincas" WHERE "nombre"='Finca La Esperanza'), 'Geisha',   'natural', '2026-01-12', 60.00),
('QUI-2026-021', (SELECT "idFinca" FROM "Fincas" WHERE "nombre"='Finca El Mirador'),   'Geisha',   'natural', '2026-01-25', 95.30),
('QUI-2026-022', (SELECT "idFinca" FROM "Fincas" WHERE "nombre"='Finca El Mirador'),   'Caturra',  'lavado',  '2026-03-10', 280.75),
('NAR-2026-033', (SELECT "idFinca" FROM "Fincas" WHERE "nombre"='Finca Buenavista'),   'Bourbon',  'honey',   '2026-02-05', 350.00),
('NAR-2026-034', (SELECT "idFinca" FROM "Fincas" WHERE "nombre"='Finca Buenavista'),   'Castillo', 'lavado',  '2026-03-15', 300.00);

INSERT INTO "Cataciones" ("loteId", "catador", "puntajeSca", "fechaCatacion") VALUES
((SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='HUI-2026-014'), 'Diana Salazar',      86.25, '2026-03-10'),
((SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='HUI-2026-014'), 'Pedro Nel Ospina',   85.50, '2026-03-12'),
((SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='HUI-2026-015'), 'Diana Salazar',      82.00, '2026-02-25'),
((SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='QUI-2026-021'), 'Diana Salazar',      89.75, '2026-02-01'),
((SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='QUI-2026-021'), 'Laura Jimenez',      90.00, '2026-02-03'),
((SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='QUI-2026-022'), 'Pedro Nel Ospina',   83.25, '2026-03-18'),
((SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='NAR-2026-033'), 'Laura Jimenez',      84.00, '2026-02-12'),
((SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='NAR-2026-034'), 'Diana Salazar',      81.50, '2026-03-20'),
((SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='HUI-2026-016'), 'Pedro Nel Ospina',   91.25, '2026-01-20'),
((SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='TEST-0000'),    'Diana Salazar',      78.00, '2026-01-05');

-- INSERT masivo. Ya NO se capturan los ids con \gset: si en algun
-- momento se ejecuta por partes o en una sesion nueva, esas variables
-- de psql se pierden y las inserciones de LineasPedido fallarian con
-- "null value violates not-null constraint". En su lugar, LineasPedido
-- busca el id correcto con una subconsulta por clave natural, que
-- siempre funciona sin importar el orden o la sesion de ejecucion.
INSERT INTO "Tostiones" ("loteId", "fechaTostion", "kilosEntrada", "kilosSalida", "perfil") VALUES
((SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='HUI-2026-014'), '2026-03-15', 300.00, 255.00, 'medio'),
((SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='HUI-2026-015'), '2026-02-28', 400.00, 340.00, 'oscuro'),
((SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='QUI-2026-021'), '2026-02-10',  90.00,  76.50, 'claro'),
((SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='QUI-2026-022'), '2026-03-20', 270.00, 229.50, 'medio'),
((SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='NAR-2026-033'), '2026-02-15', 340.00, 289.00, 'oscuro');

INSERT INTO "Clientes" ("nombre", "pais") VALUES
('Röstwerk Berlin GmbH',        'Alemania'),
('Café Bogotá Selecto S.A.S.',  'Colombia'),
('Nordic Roasters AB',          'Suecia');

INSERT INTO "Pedidos" ("clienteId", "fechaPedido", "estado") VALUES
((SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Röstwerk Berlin GmbH'),       '2026-03-20', 'pendiente'),
((SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Café Bogotá Selecto S.A.S.'), '2026-03-18', 'confirmado'),
((SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Nordic Roasters AB'),         '2026-03-22', 'pendiente'),
((SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Röstwerk Berlin GmbH'),       '2026-03-25', 'pendiente');

INSERT INTO "LineasPedido" ("pedidoId", "tostionId", "kilos", "precioKg") VALUES
((SELECT "idPedido" FROM "Pedidos" WHERE "clienteId"=(SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Röstwerk Berlin GmbH') AND "fechaPedido"='2026-03-20'),
 (SELECT "idTostion" FROM "Tostiones" WHERE "loteId"=(SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='HUI-2026-014')), 50.00, 28000.00),
((SELECT "idPedido" FROM "Pedidos" WHERE "clienteId"=(SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Röstwerk Berlin GmbH') AND "fechaPedido"='2026-03-20'),
 (SELECT "idTostion" FROM "Tostiones" WHERE "loteId"=(SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='HUI-2026-015')), 40.00, 26000.00),
((SELECT "idPedido" FROM "Pedidos" WHERE "clienteId"=(SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Café Bogotá Selecto S.A.S.') AND "fechaPedido"='2026-03-18'),
 (SELECT "idTostion" FROM "Tostiones" WHERE "loteId"=(SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='QUI-2026-021')), 20.00, 65000.00),
((SELECT "idPedido" FROM "Pedidos" WHERE "clienteId"=(SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Nordic Roasters AB') AND "fechaPedido"='2026-03-22'),
 (SELECT "idTostion" FROM "Tostiones" WHERE "loteId"=(SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='QUI-2026-022')), 60.00, 30000.00),
((SELECT "idPedido" FROM "Pedidos" WHERE "clienteId"=(SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Nordic Roasters AB') AND "fechaPedido"='2026-03-22'),
 (SELECT "idTostion" FROM "Tostiones" WHERE "loteId"=(SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='NAR-2026-033')), 50.00, 27000.00),
((SELECT "idPedido" FROM "Pedidos" WHERE "clienteId"=(SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Röstwerk Berlin GmbH') AND "fechaPedido"='2026-03-25'),
 (SELECT "idTostion" FROM "Tostiones" WHERE "loteId"=(SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='HUI-2026-014')), 30.00, 28000.00);

INSERT INTO "Certificaciones" ("nombre") VALUES ('Organico'), ('Fair Trade');

INSERT INTO "FincaCertificacion" ("fincaId", "certificacionId", "fechaObtencion") VALUES
((SELECT "idFinca" FROM "Fincas" WHERE "nombre"='Finca La Esperanza'), (SELECT "idCertificacion" FROM "Certificaciones" WHERE "nombre"='Organico'),   '2024-05-10'),
((SELECT "idFinca" FROM "Fincas" WHERE "nombre"='Finca El Mirador'),   (SELECT "idCertificacion" FROM "Certificaciones" WHERE "nombre"='Fair Trade'), '2023-11-01'),
((SELECT "idFinca" FROM "Fincas" WHERE "nombre"='Finca El Mirador'),   (SELECT "idCertificacion" FROM "Certificaciones" WHERE "nombre"='Organico'),   '2024-01-15'),
((SELECT "idFinca" FROM "Fincas" WHERE "nombre"='Finca Buenavista'),   (SELECT "idCertificacion" FROM "Certificaciones" WHERE "nombre"='Fair Trade'), '2022-08-20');

CREATE TABLE "LotesEspecialidad" (
    "codigoLote"      VARCHAR(20),
    "puntajePromedio" NUMERIC(5,2)
);

INSERT INTO "LotesEspecialidad" ("codigoLote", "puntajePromedio")
SELECT l."codigoLote", AVG(c."puntajeSca")
FROM "Lotes" l
JOIN "Cataciones" c ON c."loteId" = l."idLote"
GROUP BY l."codigoLote"
HAVING AVG(c."puntajeSca") >= 85;

SELECT * FROM "LotesEspecialidad";

-- Reflexion: LotesEspecialidad NO se actualiza sola; es una copia
-- estatica congelada en el momento del INSERT...SELECT. Para que se
-- actualizara sola usaria un TRIGGER (AFTER INSERT en Cataciones) que
-- recalculara el promedio del lote afectado, o la remplazaria por una
-- VISTA (reto 10) que se calcula en cada consulta.

-- =========================================================================
-- RETO 6. La lista de precios que llega dos veces (UPSERT) — 10 pts
-- =========================================================================
CREATE TABLE "PreciosReferencia" (
    "variedad"       VARCHAR(30) PRIMARY KEY,
    "precioKg"      NUMERIC(10,2) NOT NULL,
    "actualizadoEn" TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Semana 1
INSERT INTO "PreciosReferencia" ("variedad", "precioKg") VALUES
('Castillo', 32000.00),
('Caturra',  35500.00),
('Geisha',   120000.00);

-- Pausa breve: garantiza que actualizadoEn de la semana 2 quede
-- claramente despues del de la semana 1 (TIMESTAMP en Postgres ya
-- guarda microsegundos, pero un script que corre en milisegundos
-- podria caer en el mismo instante sin esto).
SELECT pg_sleep(1);

-- Semana 2: upsert
INSERT INTO "PreciosReferencia" ("variedad", "precioKg") VALUES ('Caturra', 36800.00)
    ON CONFLICT ("variedad") DO UPDATE SET "precioKg" = EXCLUDED."precioKg", "actualizadoEn" = NOW();
INSERT INTO "PreciosReferencia" ("variedad", "precioKg") VALUES ('Geisha', 118000.00)
    ON CONFLICT ("variedad") DO UPDATE SET "precioKg" = EXCLUDED."precioKg", "actualizadoEn" = NOW();
INSERT INTO "PreciosReferencia" ("variedad", "precioKg") VALUES ('Bourbon', 41000.00)
    ON CONFLICT ("variedad") DO UPDATE SET "precioKg" = EXCLUDED."precioKg", "actualizadoEn" = NOW();

SELECT COUNT(*) AS "totalVariedades" FROM "PreciosReferencia";
SELECT * FROM "PreciosReferencia" ORDER BY "variedad";

-- Verificacion explicita de que actualizadoEn SI cambio en las
-- variedades tocadas por el upsert de la semana 2 (Caturra, Geisha):
-- 'Castillo' nunca se volvio a insertar, asi que su actualizadoEn
-- sigue siendo el de la semana 1 (mas viejo). Si el upsert funciono,
-- el de Caturra debe ser mas reciente.
SELECT
    (SELECT "actualizadoEn" FROM "PreciosReferencia" WHERE "variedad"='Castillo') AS "castilloSemana1SinTocar",
    (SELECT "actualizadoEn" FROM "PreciosReferencia" WHERE "variedad"='Caturra') AS "caturraActualizadoSemana2",
    (SELECT "actualizadoEn" FROM "PreciosReferencia" WHERE "variedad"='Caturra')
        > (SELECT "actualizadoEn" FROM "PreciosReferencia" WHERE "variedad"='Castillo') AS "actualizadoEnSiCambio";

-- Reflexion: si "variedad" no fuera PK ni UNIQUE, ON CONFLICT no
-- tendria sobre que columna detectar el duplicado (PostgreSQL exige
-- indicar la columna/indice del conflicto), asi que cada INSERT
-- agregaria una fila nueva en vez de actualizar la existente.

-- =========================================================================
-- RETO 7. La balanza descalibrada (UPDATE) — 10 pts
-- =========================================================================
SELECT COUNT(*) AS "filasAActualizar"
FROM "Cataciones"
WHERE "catador" = 'Pedro Nel Ospina';

UPDATE "Cataciones"
SET "puntajeSca" = GREATEST("puntajeSca" - 1.5, 0)
WHERE "catador" = 'Pedro Nel Ospina';

SELECT "catador", "puntajeSca" FROM "Cataciones" WHERE "catador" = 'Pedro Nel Ospina';

SELECT COUNT(*) AS "filasAActualizar"
FROM "LineasPedido" lp
JOIN "Pedidos" p ON p."idPedido" = lp."pedidoId"
JOIN "Clientes" c ON c."idCliente" = p."clienteId"
WHERE c."pais" = 'Alemania';

-- UPDATE ... FROM (PostgreSQL)
UPDATE "LineasPedido" lp
SET "precioKg" = lp."precioKg" * 0.90
FROM "Pedidos" p, "Clientes" c
WHERE p."idPedido" = lp."pedidoId" AND c."idCliente" = p."clienteId" AND c."pais" = 'Alemania';

SELECT lp."idLinea", lp."precioKg"
FROM "LineasPedido" lp
JOIN "Pedidos" p ON p."idPedido" = lp."pedidoId"
JOIN "Clientes" c ON c."idCliente" = p."clienteId"
WHERE c."pais" = 'Alemania';

-- Reflexion: repetir el UPDATE del descuento aplicaria otro 10% sobre
-- el precio YA descontado, dejando el precio en 81% del original en
-- vez de 90%. El UPDATE no es idempotente porque el WHERE no distingue
-- si esa linea ya fue descontada.

-- =========================================================================
-- RETO 8. El caficultor que se fue (DELETE, baja logica, TRUNCATE, DROP) — 10 pts
-- =========================================================================

-- 1) DELETE bloqueado por FK
DELETE FROM "Fincas" WHERE "nombre" = 'Finca La Esperanza';
-- Error esperado (PostgreSQL):
-- ERROR:  update or delete on table "Fincas" violates foreign key
-- constraint "fk_lote_finca" on table "Lotes"
-- DETAIL:  Key (idFinca)=(...) is still referenced from table "Lotes".

-- 2) baja logica
ALTER TABLE "Fincas" ADD COLUMN "activa" BOOLEAN NOT NULL DEFAULT TRUE;
UPDATE "Fincas" SET "activa" = FALSE WHERE "nombre" = 'Finca La Esperanza';
SELECT "nombre", "activa" FROM "Fincas";

-- 3) DELETE cruzando tablas con USING, filtrando por codigoLote
DELETE FROM "Cataciones"
USING "Lotes"
WHERE "Lotes"."idLote" = "Cataciones"."loteId" AND "Lotes"."codigoLote" = 'TEST-0000';

SELECT * FROM "Cataciones" c JOIN "Lotes" l ON l."idLote" = c."loteId" WHERE l."codigoLote" = 'TEST-0000';

-- 4) vaciar y eliminar LotesEspecialidad
-- (RESTART IDENTITY aplicaria si la tabla tuviera una columna serial/
-- identity; aqui no la tiene, asi que un TRUNCATE simple basta)
TRUNCATE TABLE "LotesEspecialidad";
DROP TABLE "LotesEspecialidad";

-- Reflexion: DELETE borra fila por fila, dispara triggers, respeta las
-- FK y se puede revertir con ROLLBACK: es DML. TRUNCATE vacia la tabla
-- de un golpe, no dispara triggers por fila y en PostgreSQL SI es
-- transaccional (a diferencia de MySQL) pero sigue clasificandose como
-- DDL porque reestructura el almacenamiento de la tabla. DROP TABLE
-- elimina la tabla entera: tambien es DDL.

-- =========================================================================
-- RETO 9. El pedido que no puede quedar a medias (transacciones) — 10 pts
-- =========================================================================

ALTER TABLE "Tostiones" ADD COLUMN "kilosDisponibles" NUMERIC(10,2) NOT NULL DEFAULT 0;
ALTER TABLE "Tostiones"
    ADD CONSTRAINT chk_tostion_disponible CHECK ("kilosDisponibles" >= 0);

UPDATE "Tostiones" t
SET "kilosDisponibles" = t."kilosSalida" - (
    SELECT COALESCE(SUM(lp."kilos"), 0) FROM "LineasPedido" lp WHERE lp."tostionId" = t."idTostion"
);

SELECT "idTostion", "kilosSalida", "kilosDisponibles" FROM "Tostiones";

-- 2) transaccion: pedido de 2 lineas que descuenta inventario
-- (subconsultas por clave natural en vez de \gset: asi funciona sin
-- importar la sesion/orden de ejecucion en el cliente)
BEGIN;
    INSERT INTO "Pedidos" ("clienteId", "fechaPedido", "estado")
    VALUES ((SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Nordic Roasters AB'), '2026-03-28', 'pendiente');

    INSERT INTO "LineasPedido" ("pedidoId", "tostionId", "kilos", "precioKg") VALUES (
        (SELECT "idPedido" FROM "Pedidos" WHERE "clienteId"=(SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Nordic Roasters AB') AND "fechaPedido"='2026-03-28'),
        (SELECT "idTostion" FROM "Tostiones" WHERE "loteId"=(SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='HUI-2026-014')), 20.00, 28500.00);
    UPDATE "Tostiones" SET "kilosDisponibles" = "kilosDisponibles" - 20.00
        WHERE "loteId" = (SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='HUI-2026-014');

    INSERT INTO "LineasPedido" ("pedidoId", "tostionId", "kilos", "precioKg") VALUES (
        (SELECT "idPedido" FROM "Pedidos" WHERE "clienteId"=(SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Nordic Roasters AB') AND "fechaPedido"='2026-03-28'),
        (SELECT "idTostion" FROM "Tostiones" WHERE "loteId"=(SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='QUI-2026-021')), 15.00, 66000.00);
    UPDATE "Tostiones" SET "kilosDisponibles" = "kilosDisponibles" - 15.00
        WHERE "loteId" = (SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='QUI-2026-021');
COMMIT;

SELECT t."idTostion", t."kilosDisponibles", l."codigoLote"
FROM "Tostiones" t JOIN "Lotes" l ON l."idLote" = t."loteId"
WHERE l."codigoLote" IN ('HUI-2026-014','QUI-2026-021');

-- 3) simular el desastre: pedir mas kilos de los disponibles
BEGIN;
    INSERT INTO "Pedidos" ("clienteId", "fechaPedido", "estado")
    VALUES ((SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Nordic Roasters AB'), '2026-03-29', 'pendiente');

    INSERT INTO "LineasPedido" ("pedidoId", "tostionId", "kilos", "precioKg") VALUES (
        (SELECT "idPedido" FROM "Pedidos" WHERE "clienteId"=(SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Nordic Roasters AB') AND "fechaPedido"='2026-03-29'),
        (SELECT "idTostion" FROM "Tostiones" WHERE "loteId"=(SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='QUI-2026-021')), 1000.00, 66000.00);
    UPDATE "Tostiones" SET "kilosDisponibles" = "kilosDisponibles" - 1000.00
        WHERE "loteId" = (SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='QUI-2026-021');
    -- Error esperado:
    -- ERROR:  new row for relation "Tostiones" violates check constraint "chk_tostion_disponible"
ROLLBACK;

-- Se espera 0 filas (el pedido nunca se confirmo, por el ROLLBACK)
SELECT * FROM "Pedidos" WHERE "fechaPedido" = '2026-03-29';

-- 4) SAVEPOINT: deshacer solo la segunda linea
BEGIN;
    INSERT INTO "Pedidos" ("clienteId", "fechaPedido", "estado")
    VALUES ((SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Café Bogotá Selecto S.A.S.'), '2026-03-30', 'pendiente');

    INSERT INTO "LineasPedido" ("pedidoId", "tostionId", "kilos", "precioKg") VALUES (
        (SELECT "idPedido" FROM "Pedidos" WHERE "clienteId"=(SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Café Bogotá Selecto S.A.S.') AND "fechaPedido"='2026-03-30'),
        (SELECT "idTostion" FROM "Tostiones" WHERE "loteId"=(SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='HUI-2026-015')), 10.00, 27000.00);
    UPDATE "Tostiones" SET "kilosDisponibles" = "kilosDisponibles" - 10.00
        WHERE "loteId" = (SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='HUI-2026-015');

    SAVEPOINT antes_linea_2;

    INSERT INTO "LineasPedido" ("pedidoId", "tostionId", "kilos", "precioKg") VALUES (
        (SELECT "idPedido" FROM "Pedidos" WHERE "clienteId"=(SELECT "idCliente" FROM "Clientes" WHERE "nombre"='Café Bogotá Selecto S.A.S.') AND "fechaPedido"='2026-03-30'),
        (SELECT "idTostion" FROM "Tostiones" WHERE "loteId"=(SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='HUI-2026-015')), 99999.00, 27000.00);
    UPDATE "Tostiones" SET "kilosDisponibles" = "kilosDisponibles" - 99999.00
        WHERE "loteId" = (SELECT "idLote" FROM "Lotes" WHERE "codigoLote"='HUI-2026-015');
    -- viola el CHECK; deshacemos solo hasta el SAVEPOINT
    ROLLBACK TO SAVEPOINT antes_linea_2;
COMMIT;

SELECT lp.* FROM "LineasPedido" lp
JOIN "Pedidos" p ON p."idPedido" = lp."pedidoId"
JOIN "Clientes" c ON c."idCliente" = p."clienteId"
WHERE c."nombre"='Café Bogotá Selecto S.A.S.' AND p."fechaPedido"='2026-03-30';
-- Se espera solo 1 linea (la segunda se deshizo con el SAVEPOINT)

-- 5) experimento comparativo: DDL dentro de una transaccion + ROLLBACK
BEGIN;
    CREATE TABLE "Prueba" ("id" INT);
ROLLBACK;

SELECT to_regclass('operacion.Prueba') AS "existeTablaPrueba";
-- En PostgreSQL da NULL: la tabla NO existe (ver reflexion).

-- Reflexion: en PostgreSQL el DDL es transaccional, asi que el
-- ROLLBACK deshace tambien el CREATE TABLE ("Prueba" no existe
-- despues). En MySQL, en cambio, CREATE TABLE provoca un commit
-- implicito y la tabla sigue existiendo pese al ROLLBACK. El riesgo
-- practico para un script de migracion en MySQL es que mezclar DDL y
-- DML en una misma transaccion rompe la atomicidad: si algo falla
-- despues del CREATE TABLE, ese cambio de estructura no se revierte
-- aunque el resto si, dejando la base en un estado intermedio.

-- =========================================================================
-- RETO 10. El QR que cuenta la historia (VISTA) — 10 pts
-- =========================================================================
DROP VIEW IF EXISTS "Trazabilidad";

CREATE OR REPLACE VIEW "Trazabilidad" AS
SELECT
    c."nombre"                     AS "cliente",
    c."pais"                       AS "paisCliente",
    f."nombre"                     AS "finca",
    f."caficultor"                 AS "caficultor",
    f."municipio"                  AS "municipio",
    f."altitudM"                  AS "altitudM",
    l."variedad"                   AS "variedad",
    l."proceso"                    AS "proceso",
    sca."puntajePromedio"         AS "puntajeScaPromedio",
    t."fechaTostion"              AS "fechaTostion",
    t."perfil"                     AS "perfilTostion",
    -- Dato creativo: Certificaciones vigentes de la finca, para que el
    -- consumidor sepa si el cafe es organico y/o de comercio justo.
    certs."listaCertificaciones"  AS "certificaciones",
    CONCAT(
        l."variedad", ' ', l."proceso", ' de ', f."nombre", ', ', f."municipio",
        ' (', f."altitudM", ' m). Puntaje ', sca."puntajePromedio",
        '. Tostado ', t."perfil", ' el ', t."fechaTostion",
        CASE WHEN certs."listaCertificaciones" IS NOT NULL
             THEN CONCAT('. Certificado: ', certs."listaCertificaciones", '.')
             ELSE '.' END
    ) AS "textoQr"
FROM "LineasPedido" lp
JOIN "Pedidos"   p  ON p."idPedido" = lp."pedidoId"
JOIN "Clientes"  c  ON c."idCliente" = p."clienteId"
JOIN "Tostiones" t  ON t."idTostion" = lp."tostionId"
JOIN "Lotes"     l  ON l."idLote" = t."loteId"
JOIN "Fincas"    f  ON f."idFinca" = l."fincaId"
LEFT JOIN (
    SELECT "loteId", ROUND(AVG("puntajeSca"), 2) AS "puntajePromedio"
    FROM "Cataciones"
    GROUP BY "loteId"
) sca ON sca."loteId" = l."idLote"
LEFT JOIN (
    SELECT fc."fincaId", STRING_AGG(cert."nombre", ' + ') AS "listaCertificaciones"
    FROM "FincaCertificacion" fc
    JOIN "Certificaciones" cert ON cert."idCertificacion" = fc."certificacionId"
    GROUP BY fc."fincaId"
) certs ON certs."fincaId" = f."idFinca";

SELECT * FROM "Trazabilidad" WHERE "cliente" = 'Röstwerk Berlin GmbH';

-- Reflexion: una vista NO guarda datos propios: es una consulta
-- guardada que se ejecuta cada vez que se invoca, asi que siempre
-- refleja el estado actual de las tablas base. La ventaja frente a
-- LotesEspecialidad (reto 5) es que nunca queda desactualizada ni usa
-- espacio extra; la desventaja es que si la consulta es pesada se
-- recalcula cada vez (para eso existen las vistas materializadas,
-- MATERIALIZED VIEW, exclusivas de PostgreSQL entre estos dos motores).
