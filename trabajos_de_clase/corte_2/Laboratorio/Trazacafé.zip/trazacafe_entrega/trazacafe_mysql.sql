-- =========================================================================
-- TRAZACAFE - LABORATORIO DDL Y DML
-- Motor: MySQL 8.0+
-- =========================================================================

-- =========================================================================
-- RETO 1. El plano de la finca (diseño) — 10 pts
-- =========================================================================
-- El modelo relacional completo, el diagrama y el diccionario de datos
-- están en el archivo 01_modelo_trazacafe.md que acompaña esta entrega.
-- Entidades identificadas (7, más 3 auxiliares que aparecen en retos
-- posteriores): Fincas, Clientes, Lotes, Cataciones, Tostiones, Pedidos,
-- LineasPedido, Certificaciones, FincaCertificacion, PreciosReferencia.
--
-- Reflexion: el requerimiento 6 (no perder historial si un caficultor se
-- va) se resuelve con ON DELETE RESTRICT en las FK Lotes.fincaId y
-- Pedidos.clienteId: el motor impide borrar fisicamente una finca o un
-- cliente que ya tiene Lotes o Pedidos asociados. Para retirar un
-- caficultor sin perder el historial se usa una baja logica (columna
-- Fincas.activa, agregada en el reto 8) en lugar de un DELETE fisico.

-- =========================================================================
-- RETO 2. Los cimientos (CREATE DATABASE / TABLE) — 10 pts
-- =========================================================================
DROP DATABASE IF EXISTS trazacafe;
CREATE DATABASE trazacafe;
USE trazacafe;

-- Desactiva el modo "safe updates" de MySQL Workbench para esta sesion.
-- Varias sentencias de este script (retos 7, 8 y 9) hacen UPDATE/DELETE
-- filtrando por columnas de negocio (nombre, codigoLote, catador) en
-- vez de por id, o sin WHERE cuando aplica a todas las filas a
-- proposito (ver reto 9). Workbench bloquea eso por defecto con el
-- error 1175 aunque la sentencia sea correcta; esto lo desactiva sin
-- necesidad de tocar preferencias en la interfaz.
SET SQL_SAFE_UPDATES = 0;

-- Orden de creacion: primero las tablas que no dependen de nadie.

CREATE TABLE Fincas (
    idFinca     INT AUTO_INCREMENT PRIMARY KEY,
    nombre       VARCHAR(100) NOT NULL,
    caficultor   VARCHAR(100) NOT NULL,
    municipio    VARCHAR(80)  NOT NULL,
    departamento VARCHAR(80)  NOT NULL,
    altitudM    INT NOT NULL
);

CREATE TABLE Clientes (
    idCliente INT AUTO_INCREMENT PRIMARY KEY,
    nombre     VARCHAR(100) NOT NULL
);

CREATE TABLE Lotes (
    idLote      INT AUTO_INCREMENT PRIMARY KEY,
    codigoLote  VARCHAR(20) NOT NULL,
    fincaId     INT NOT NULL,
    variedad     VARCHAR(30) NOT NULL,
    proceso      ENUM('lavado','honey','natural') NOT NULL,
    fechaCosecha DATE NOT NULL,
    kilos        DECIMAL(7,2) NOT NULL,
    -- ON DELETE RESTRICT: un lote no puede quedar huerfano de finca;
    -- ademas protege el requerimiento 6 (no perder historial de venta).
    CONSTRAINT fk_lote_finca FOREIGN KEY (fincaId)
        REFERENCES Fincas(idFinca) ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE Cataciones (
    idCatacion   INT AUTO_INCREMENT PRIMARY KEY,
    loteId       INT NOT NULL,
    catador       VARCHAR(80) NOT NULL,
    puntajeSca   DECIMAL(5,2) NOT NULL,
    fechaCatacion DATE NOT NULL,
    -- ON DELETE RESTRICT: preserva las catas historicas del lote.
    CONSTRAINT fk_catacion_lote FOREIGN KEY (loteId)
        REFERENCES Lotes(idLote) ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE Tostiones (
    idTostion     INT AUTO_INCREMENT PRIMARY KEY,
    loteId        INT NOT NULL,
    fechaTostion  DATE NOT NULL,
    kilosEntrada  DECIMAL(7,2) NOT NULL,
    kilosSalida   DECIMAL(7,2) NOT NULL,
    perfil         ENUM('claro','medio','oscuro') NOT NULL,
    -- ON DELETE RESTRICT: idem, no perder trazabilidad del lote.
    CONSTRAINT fk_tostion_lote FOREIGN KEY (loteId)
        REFERENCES Lotes(idLote) ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE Pedidos (
    idPedido    INT AUTO_INCREMENT PRIMARY KEY,
    clienteId   INT NOT NULL,
    fechaPedido DATE NOT NULL DEFAULT (CURRENT_DATE),
    estado       VARCHAR(20) NOT NULL DEFAULT 'pendiente',
    -- ON DELETE RESTRICT: preserva el historial de ventas del cliente
    -- (extension del mismo criterio del requerimiento 6).
    CONSTRAINT fk_pedido_cliente FOREIGN KEY (clienteId)
        REFERENCES Clientes(idCliente) ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE LineasPedido (
    idLinea   INT AUTO_INCREMENT PRIMARY KEY,
    pedidoId  INT NOT NULL,
    tostionId INT NOT NULL,
    kilos      DECIMAL(7,2) NOT NULL,
    precioKg  DECIMAL(10,2) NOT NULL,
    -- ON DELETE CASCADE: si se anula la cabecera del pedido, sus
    -- lineas no tienen sentido por si solas.
    CONSTRAINT fk_linea_pedido FOREIGN KEY (pedidoId)
        REFERENCES Pedidos(idPedido) ON UPDATE CASCADE ON DELETE CASCADE,
    -- ON DELETE RESTRICT: no perder que se vendio de esa tostion.
    CONSTRAINT fk_linea_tostion FOREIGN KEY (tostionId)
        REFERENCES Tostiones(idTostion) ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Verificar version (los CHECK solo se validan desde 8.0.16):
SELECT VERSION();
DESCRIBE Lotes;

-- Reflexion: si se crea primero "Lotes" y despues "Fincas", el motor
-- rechaza el CREATE TABLE de Lotes porque su FK fincaId referencia una
-- tabla que todavia no existe. MySQL exige que la tabla referenciada
-- por una FK ya exista en el momento de crear la que la referencia.

-- =========================================================================
-- RETO 3. Los guardianes de la calidad (CHECK, UNIQUE, Prueba de fuego) — 10 pts
-- =========================================================================
ALTER TABLE Fincas
    ADD CONSTRAINT chk_finca_altitud CHECK (altitudM BETWEEN 800 AND 2500);

ALTER TABLE Lotes
    ADD CONSTRAINT uq_lote_codigo UNIQUE (codigoLote);

ALTER TABLE Cataciones
    ADD CONSTRAINT chk_catacion_puntaje CHECK (puntajeSca BETWEEN 0 AND 100);

ALTER TABLE Tostiones
    ADD CONSTRAINT chk_tostion_kilos CHECK (kilosSalida <= kilosEntrada);

ALTER TABLE Pedidos
    ADD CONSTRAINT chk_pedido_estado
        CHECK (estado IN ('pendiente','confirmado','enviado','entregado','cancelado'));

-- Semilla de Prueba (finca y lote "de Prueba" que tambien se usan en el
-- reto 8 para demostrar el DELETE cruzado y la baja logica):
INSERT INTO Fincas (nombre, caficultor, municipio, departamento, altitudM)
VALUES ('Finca Prueba QA', 'Datos de Prueba', 'Pitalito', 'Huila', 1200);

INSERT INTO Lotes (codigoLote, fincaId, variedad, proceso, fechaCosecha, kilos)
VALUES ('TEST-0000', LAST_INSERT_ID(), 'Caturra', 'lavado', '2026-01-01', 10.00);

-- --- Prueba de fuego: un INSERT que viola cada restriccion a proposito ---

-- (a) altitud fuera de rango [800,2500] -> viola chk_finca_altitud
INSERT INTO Fincas (nombre, caficultor, municipio, departamento, altitudM)
VALUES ('Finca Altitud Invalida', 'N/A', 'N/A', 'N/A', 100);
-- Error esperado (MariaDB):
-- ERROR 4025 (23000): CONSTRAINT `chk_finca_altitud` failed for `trazacafe`.`Fincas`

-- (b) codigoLote repetido -> viola uq_lote_codigo
INSERT INTO Lotes (codigoLote, fincaId, variedad, proceso, fechaCosecha, kilos)
VALUES ('TEST-0000', 1, 'Castillo', 'honey', '2026-01-02', 20.00);
-- Error esperado:
-- ERROR 1062 (23000): Duplicate entry 'TEST-0000' for key 'uq_lote_codigo'

-- (c) puntaje SCA fuera de [0,100] -> viola chk_catacion_puntaje
INSERT INTO Cataciones (loteId, catador, puntajeSca, fechaCatacion)
VALUES (1, 'Catador Invalido', 150.00, '2026-01-03');
-- Error esperado:
-- ERROR 4025 (23000): CONSTRAINT `chk_catacion_puntaje` failed for `trazacafe`.`Cataciones`

-- (d) kilosSalida > kilosEntrada -> viola chk_tostion_kilos
INSERT INTO Tostiones (loteId, fechaTostion, kilosEntrada, kilosSalida, perfil)
VALUES (1, '2026-01-04', 5.00, 9.00, 'medio');
-- Error esperado:
-- ERROR 4025 (23000): CONSTRAINT `chk_tostion_kilos` failed for `trazacafe`.`Tostiones`

-- Reflexion: la regla "un lote puede catarse mas de una vez" o que el
-- puntaje promedio de un lote (agregado entre varias filas de
-- Cataciones) determine si es "cafe de especialidad" NO se puede
-- expresar con un CHECK, porque un CHECK solo evalua columnas de la
-- MISMA fila en el momento del INSERT/UPDATE: no puede mirar otras
-- filas ni otras tablas. Para reglas que dependan de agregados o de
-- comparar contra el historico se necesitan TRIGGERS o validacion en
-- la aplicacion (ver reto 5, donde ese calculo se hace con GROUP BY).

-- =========================================================================
-- RETO 4. Llego el correo de Berlin (ALTER TABLE) — 10 pts
-- =========================================================================

-- 1) pais en Clientes, obligatorio, default 'Colombia'
ALTER TABLE Clientes
    ADD COLUMN pais VARCHAR(60) NOT NULL DEFAULT 'Colombia';

-- 2) huella de carbono en Tostiones, nula, nunca negativa
ALTER TABLE Tostiones
    ADD COLUMN huellaCarbonoKg DECIMAL(8,2) NULL;
ALTER TABLE Tostiones
    ADD CONSTRAINT chk_tostion_huella CHECK (huellaCarbonoKg IS NULL OR huellaCarbonoKg >= 0);

-- 3) ampliar precision de todas las columnas de kilos: (7,2) -> (10,2)
ALTER TABLE Lotes      MODIFY COLUMN kilos         DECIMAL(10,2) NOT NULL;
ALTER TABLE Tostiones  MODIFY COLUMN kilosEntrada DECIMAL(10,2) NOT NULL;
ALTER TABLE Tostiones  MODIFY COLUMN kilosSalida  DECIMAL(10,2) NOT NULL;
ALTER TABLE LineasPedido MODIFY COLUMN kilos      DECIMAL(10,2) NOT NULL;

-- 4) una finca puede tener varias Certificaciones y viceversa -> N:M
CREATE TABLE Certificaciones (
    idCertificacion INT AUTO_INCREMENT PRIMARY KEY,
    nombre           VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE FincaCertificacion (
    fincaId         INT NOT NULL,
    certificacionId INT NOT NULL,
    fechaObtencion  DATE NOT NULL,
    PRIMARY KEY (fincaId, certificacionId),
    -- ON DELETE CASCADE: si la finca se elimina fisicamente (caso
    -- excepcional, ver reto 8), sus Certificaciones ya no aplican.
    CONSTRAINT fk_fc_finca FOREIGN KEY (fincaId)
        REFERENCES Fincas(idFinca) ON UPDATE CASCADE ON DELETE CASCADE,
    -- ON DELETE RESTRICT: no borrar un tipo de certificacion en uso.
    CONSTRAINT fk_fc_certificacion FOREIGN KEY (certificacionId)
        REFERENCES Certificaciones(idCertificacion) ON UPDATE CASCADE ON DELETE RESTRICT
);

-- 5) renombrar columna mal nombrada: "kilos" en Lotes no deja claro
--    que es el peso COSECHADO (se confunde con kilosEntrada/salida de
--    Tostiones). La renombramos a kilosCosechados.
-- CHANGE COLUMN en vez de RENAME COLUMN: esta ultima solo existe desde
-- MariaDB 10.5.2 / MySQL 8.0; CHANGE COLUMN (repitiendo el tipo) es
-- compatible con versiones mas viejas de ambos motores.
ALTER TABLE Lotes CHANGE COLUMN kilos kilosCosechados DECIMAL(10,2) NOT NULL;

DESCRIBE Lotes;
DESCRIBE Tostiones;

-- Reflexion: borrar y recrear una tabla en produccion es peligroso
-- porque se pierden los datos y el historial, se rompen o disparan en
-- cascada las FK de otras tablas que la referencian, el servicio queda
-- sin esa tabla mientras no existe, y cualquier vista, indice o permiso
-- asociado desaparece con ella. ALTER TABLE cambia la estructura sin
-- sacrificar los datos ni los vinculos ya existentes.

-- =========================================================================
-- RETO 5. La primera cosecha (INSERT masivos) — 10 pts
-- =========================================================================
-- La Finca Prueba QA y el Lote TEST-0000 ya se cargaron en el reto 3;
-- aqui se completa el resto del dataset minimo pedido.

-- 3 Fincas mas (con la de Prueba ya son 4, en 3 departamentos: Huila,
-- Quindio, Narino) — insercion de varias filas en un solo INSERT.
INSERT INTO Fincas (nombre, caficultor, municipio, departamento, altitudM) VALUES
('Finca La Esperanza', 'Jorge Ivan Bolanos',  'Pitalito', 'Huila',   1750),
('Finca El Mirador',   'Marta Elena Rios',    'Salento',  'Quindio', 1900),
('Finca Buenavista',   'Camilo Andres Munoz', 'Buesaco',  'Narino',  2100);

-- 7 Lotes mas (con TEST-0000 ya son 8)
INSERT INTO Lotes (codigoLote, fincaId, variedad, proceso, fechaCosecha, kilosCosechados) VALUES
('HUI-2026-014', (SELECT idFinca FROM Fincas WHERE nombre='Finca La Esperanza'), 'Caturra',  'lavado',  '2026-03-02', 320.50),
('HUI-2026-015', (SELECT idFinca FROM Fincas WHERE nombre='Finca La Esperanza'), 'Castillo', 'honey',   '2026-02-18', 410.00),
('HUI-2026-016', (SELECT idFinca FROM Fincas WHERE nombre='Finca La Esperanza'), 'Geisha',   'natural', '2026-01-12', 60.00),
('QUI-2026-021', (SELECT idFinca FROM Fincas WHERE nombre='Finca El Mirador'),   'Geisha',   'natural', '2026-01-25', 95.30),
('QUI-2026-022', (SELECT idFinca FROM Fincas WHERE nombre='Finca El Mirador'),   'Caturra',  'lavado',  '2026-03-10', 280.75),
('NAR-2026-033', (SELECT idFinca FROM Fincas WHERE nombre='Finca Buenavista'),   'Bourbon',  'honey',   '2026-02-05', 350.00),
('NAR-2026-034', (SELECT idFinca FROM Fincas WHERE nombre='Finca Buenavista'),   'Castillo', 'lavado',  '2026-03-15', 300.00);

-- 10 Cataciones (2 catadores + 1) sobre distintos Lotes, incluida
-- TEST-0000 (esa catacion se borrara en el reto 8, por eso su puntaje
-- bajo no afecta LotesEspecialidad).
INSERT INTO Cataciones (loteId, catador, puntajeSca, fechaCatacion) VALUES
((SELECT idLote FROM Lotes WHERE codigoLote='HUI-2026-014'), 'Diana Salazar',      86.25, '2026-03-10'),
((SELECT idLote FROM Lotes WHERE codigoLote='HUI-2026-014'), 'Pedro Nel Ospina',   85.50, '2026-03-12'),
((SELECT idLote FROM Lotes WHERE codigoLote='HUI-2026-015'), 'Diana Salazar',      82.00, '2026-02-25'),
((SELECT idLote FROM Lotes WHERE codigoLote='QUI-2026-021'), 'Diana Salazar',      89.75, '2026-02-01'),
((SELECT idLote FROM Lotes WHERE codigoLote='QUI-2026-021'), 'Laura Jimenez',      90.00, '2026-02-03'),
((SELECT idLote FROM Lotes WHERE codigoLote='QUI-2026-022'), 'Pedro Nel Ospina',   83.25, '2026-03-18'),
((SELECT idLote FROM Lotes WHERE codigoLote='NAR-2026-033'), 'Laura Jimenez',      84.00, '2026-02-12'),
((SELECT idLote FROM Lotes WHERE codigoLote='NAR-2026-034'), 'Diana Salazar',      81.50, '2026-03-20'),
((SELECT idLote FROM Lotes WHERE codigoLote='HUI-2026-016'), 'Pedro Nel Ospina',   91.25, '2026-01-20'),
((SELECT idLote FROM Lotes WHERE codigoLote='TEST-0000'),    'Diana Salazar',      78.00, '2026-01-05');

-- 5 Tostiones — un solo INSERT masivo. Ya NO se capturan los ids con
-- variables de sesion (@var): en Clientes como DBeaver, si reconectas
-- o vuelves a correr solo una parte del script, esas variables se
-- resetean a NULL y las inserciones de LineasPedido truenan con
-- "Column cannot be null". En su lugar, LineasPedido busca el id
-- correcto con una subconsulta por clave natural (codigoLote /
-- nombre+fecha), que siempre funciona sin importar el orden o la
-- sesion en que se ejecute.
INSERT INTO Tostiones (loteId, fechaTostion, kilosEntrada, kilosSalida, perfil) VALUES
((SELECT idLote FROM Lotes WHERE codigoLote='HUI-2026-014'), '2026-03-15', 300.00, 255.00, 'medio'),
((SELECT idLote FROM Lotes WHERE codigoLote='HUI-2026-015'), '2026-02-28', 400.00, 340.00, 'oscuro'),
((SELECT idLote FROM Lotes WHERE codigoLote='QUI-2026-021'), '2026-02-10',  90.00,  76.50, 'claro'),
((SELECT idLote FROM Lotes WHERE codigoLote='QUI-2026-022'), '2026-03-20', 270.00, 229.50, 'medio'),
((SELECT idLote FROM Lotes WHERE codigoLote='NAR-2026-033'), '2026-02-15', 340.00, 289.00, 'oscuro');

-- 3 Clientes (uno en Alemania)
INSERT INTO Clientes (nombre, pais) VALUES
('Röstwerk Berlin GmbH',        'Alemania'),
('Café Bogotá Selecto S.A.S.',  'Colombia'),
('Nordic Roasters AB',          'Suecia');

-- 4 Pedidos con al menos 6 lineas en total
INSERT INTO Pedidos (clienteId, fechaPedido, estado) VALUES
((SELECT idCliente FROM Clientes WHERE nombre='Röstwerk Berlin GmbH'),       '2026-03-20', 'pendiente'),
((SELECT idCliente FROM Clientes WHERE nombre='Café Bogotá Selecto S.A.S.'), '2026-03-18', 'confirmado'),
((SELECT idCliente FROM Clientes WHERE nombre='Nordic Roasters AB'),         '2026-03-22', 'pendiente'),
((SELECT idCliente FROM Clientes WHERE nombre='Röstwerk Berlin GmbH'),       '2026-03-25', 'pendiente');

-- Atajos de lectura para las subconsultas de abajo: cada tostion es
-- unica por lote (un lote se tuesta una sola vez en este dataset), y
-- cada pedido es unico por cliente+fecha.
INSERT INTO LineasPedido (pedidoId, tostionId, kilos, precioKg) VALUES
((SELECT idPedido FROM Pedidos WHERE clienteId=(SELECT idCliente FROM Clientes WHERE nombre='Röstwerk Berlin GmbH') AND fechaPedido='2026-03-20'),
 (SELECT idTostion FROM Tostiones WHERE loteId=(SELECT idLote FROM Lotes WHERE codigoLote='HUI-2026-014')), 50.00, 28000.00),
((SELECT idPedido FROM Pedidos WHERE clienteId=(SELECT idCliente FROM Clientes WHERE nombre='Röstwerk Berlin GmbH') AND fechaPedido='2026-03-20'),
 (SELECT idTostion FROM Tostiones WHERE loteId=(SELECT idLote FROM Lotes WHERE codigoLote='HUI-2026-015')), 40.00, 26000.00),
((SELECT idPedido FROM Pedidos WHERE clienteId=(SELECT idCliente FROM Clientes WHERE nombre='Café Bogotá Selecto S.A.S.') AND fechaPedido='2026-03-18'),
 (SELECT idTostion FROM Tostiones WHERE loteId=(SELECT idLote FROM Lotes WHERE codigoLote='QUI-2026-021')), 20.00, 65000.00),
((SELECT idPedido FROM Pedidos WHERE clienteId=(SELECT idCliente FROM Clientes WHERE nombre='Nordic Roasters AB') AND fechaPedido='2026-03-22'),
 (SELECT idTostion FROM Tostiones WHERE loteId=(SELECT idLote FROM Lotes WHERE codigoLote='QUI-2026-022')), 60.00, 30000.00),
((SELECT idPedido FROM Pedidos WHERE clienteId=(SELECT idCliente FROM Clientes WHERE nombre='Nordic Roasters AB') AND fechaPedido='2026-03-22'),
 (SELECT idTostion FROM Tostiones WHERE loteId=(SELECT idLote FROM Lotes WHERE codigoLote='NAR-2026-033')), 50.00, 27000.00),
((SELECT idPedido FROM Pedidos WHERE clienteId=(SELECT idCliente FROM Clientes WHERE nombre='Röstwerk Berlin GmbH') AND fechaPedido='2026-03-25'),
 (SELECT idTostion FROM Tostiones WHERE loteId=(SELECT idLote FROM Lotes WHERE codigoLote='HUI-2026-014')), 30.00, 28000.00);

-- Certificaciones del reto 4
INSERT INTO Certificaciones (nombre) VALUES ('Organico'), ('Fair Trade');

INSERT INTO FincaCertificacion (fincaId, certificacionId, fechaObtencion) VALUES
((SELECT idFinca FROM Fincas WHERE nombre='Finca La Esperanza'), (SELECT idCertificacion FROM Certificaciones WHERE nombre='Organico'),   '2024-05-10'),
((SELECT idFinca FROM Fincas WHERE nombre='Finca El Mirador'),   (SELECT idCertificacion FROM Certificaciones WHERE nombre='Fair Trade'), '2023-11-01'),
((SELECT idFinca FROM Fincas WHERE nombre='Finca El Mirador'),   (SELECT idCertificacion FROM Certificaciones WHERE nombre='Organico'),   '2024-01-15'),
((SELECT idFinca FROM Fincas WHERE nombre='Finca Buenavista'),   (SELECT idCertificacion FROM Certificaciones WHERE nombre='Fair Trade'), '2022-08-20');

-- LotesEspecialidad: copia los Lotes con puntaje promedio >= 85
CREATE TABLE LotesEspecialidad (
    codigoLote      VARCHAR(20),
    puntajePromedio DECIMAL(5,2)
);

INSERT INTO LotesEspecialidad (codigoLote, puntajePromedio)
SELECT l.codigoLote, AVG(c.puntajeSca)
FROM Lotes l
JOIN Cataciones c ON c.loteId = l.idLote
GROUP BY l.codigoLote
HAVING AVG(c.puntajeSca) >= 85;

SELECT * FROM LotesEspecialidad;

-- Reflexion: LotesEspecialidad NO se actualiza sola; es una copia
-- estatica que quedo congelada en el momento del INSERT...SELECT y no
-- refleja Cataciones nuevas. Para que se actualizara sola usaria un
-- TRIGGER (AFTER INSERT en Cataciones) que recalculara el promedio del
-- lote afectado, o remplazaria la tabla por una VISTA (como la del
-- reto 10) que se calcula en cada consulta.

-- =========================================================================
-- RETO 6. La lista de precios que llega dos veces (UPSERT) — 10 pts
-- =========================================================================
CREATE TABLE PreciosReferencia (
    variedad       VARCHAR(30) PRIMARY KEY,
    precioKg      DECIMAL(10,2) NOT NULL,
    actualizadoEn DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
);

-- Semana 1
INSERT INTO PreciosReferencia (variedad, precioKg) VALUES
('Castillo', 32000.00),
('Caturra',  35500.00),
('Geisha',   120000.00);

-- Pausa breve: garantiza que actualizadoEn de la semana 2 quede
-- claramente despues del de la semana 1, incluso con precision de
-- microsegundos (sin esto, en un script que corre en milisegundos, a
-- veces caen en el mismo instante y la comparacion de abajo no lo nota).
SELECT SLEEP(1);

-- Semana 2: upsert. Se usa la funcion clasica VALUES(columna) en vez de
-- "INSERT ... AS alias ON DUPLICATE KEY UPDATE alias.columna": esa
-- sintaxis con alias solo existe en MySQL 8.0.19+, MariaDB nunca la
-- adopto. VALUES() esta deprecada en MySQL 8.0 (dará un warning) pero
-- sigue funcionando, y es la unica forma que entienden ambos motores.
INSERT INTO PreciosReferencia (variedad, precioKg) VALUES ('Caturra', 36800.00)
    ON DUPLICATE KEY UPDATE precioKg = VALUES(precioKg), actualizadoEn = NOW();
INSERT INTO PreciosReferencia (variedad, precioKg) VALUES ('Geisha', 118000.00)
    ON DUPLICATE KEY UPDATE precioKg = VALUES(precioKg), actualizadoEn = NOW();
INSERT INTO PreciosReferencia (variedad, precioKg) VALUES ('Bourbon', 41000.00)
    ON DUPLICATE KEY UPDATE precioKg = VALUES(precioKg), actualizadoEn = NOW();

-- Verificacion: deben quedar 4 variedades
SELECT COUNT(*) AS totalVariedades FROM PreciosReferencia;
SELECT * FROM PreciosReferencia ORDER BY variedad;

-- Verificacion explicita de que actualizadoEn SI cambio en las
-- variedades tocadas por el upsert de la semana 2 (Caturra, Geisha):
-- 'Castillo' nunca se volvio a insertar, asi que su actualizadoEn
-- sigue siendo el de la semana 1 (mas viejo). Si el upsert funciono,
-- el de Caturra debe ser mas reciente.
SELECT
    (SELECT actualizadoEn FROM PreciosReferencia WHERE variedad='Castillo') AS castilloSemana1SinTocar,
    (SELECT actualizadoEn FROM PreciosReferencia WHERE variedad='Caturra') AS caturraActualizadoSemana2,
    (SELECT actualizadoEn FROM PreciosReferencia WHERE variedad='Caturra')
        > (SELECT actualizadoEn FROM PreciosReferencia WHERE variedad='Castillo') AS actualizadoEnSiCambio;

-- Reflexion: si "variedad" no fuera PK ni UNIQUE, el motor no tendria
-- sobre que columna detectar el duplicado para el ON DUPLICATE KEY, asi
-- que cada INSERT agregaria una fila nueva en lugar de actualizar la
-- existente; PreciosReferencia terminaria con variedades repetidas y
-- precios historicos mezclados, sin poder saber cual es el vigente.

-- =========================================================================
-- RETO 7. La balanza descalibrada (UPDATE) — 10 pts
-- =========================================================================
-- Catador con la balanza descalibrada: Pedro Nel Ospina

-- Paso previo de buena practica: contar cuantas filas deberian cambiar
SELECT COUNT(*) AS filasAActualizar
FROM Cataciones
WHERE catador = 'Pedro Nel Ospina';

UPDATE Cataciones
SET puntajeSca = GREATEST(puntajeSca - 1.5, 0)
WHERE catador = 'Pedro Nel Ospina';

SELECT catador, puntajeSca FROM Cataciones WHERE catador = 'Pedro Nel Ospina';

-- Paso previo de buena practica para el descuento del cliente aleman
SELECT COUNT(*) AS filasAActualizar
FROM LineasPedido lp
JOIN Pedidos p ON p.idPedido = lp.pedidoId
JOIN Clientes c ON c.idCliente = p.clienteId
WHERE c.pais = 'Alemania';

-- UPDATE con JOIN (MySQL)
UPDATE LineasPedido lp
JOIN Pedidos p  ON p.idPedido = lp.pedidoId
JOIN Clientes c ON c.idCliente = p.clienteId
SET lp.precioKg = lp.precioKg * 0.90
WHERE c.pais = 'Alemania';

SELECT lp.idLinea, lp.precioKg
FROM LineasPedido lp
JOIN Pedidos p  ON p.idPedido = lp.pedidoId
JOIN Clientes c ON c.idCliente = p.clienteId
WHERE c.pais = 'Alemania';

-- Reflexion: si el UPDATE del descuento se ejecutara dos veces, el 10%
-- se aplicaria de nuevo sobre el precio YA descontado (10% sobre 10%),
-- dejando el precio en 81% del original en vez de 90%. El UPDATE no es
-- idempotente porque el WHERE no distingue si esa linea ya fue
-- descontada.

-- =========================================================================
-- RETO 8. El caficultor que se fue (DELETE, baja logica, TRUNCATE, DROP) — 10 pts
-- =========================================================================

-- 1) intento de DELETE de una finca con Lotes vendidos -> debe fallar
DELETE FROM Fincas WHERE nombre = 'Finca La Esperanza';
-- Error esperado (MySQL):
-- ERROR 1451 (23000): Cannot delete or update a parent row: a foreign
-- key constraint fails (`trazacafe`.`Lotes`, CONSTRAINT `fk_lote_finca`
-- FOREIGN KEY (`fincaId`) REFERENCES `Fincas` (`idFinca`))

-- 2) baja logica
ALTER TABLE Fincas ADD COLUMN activa BOOLEAN NOT NULL DEFAULT TRUE;

UPDATE Fincas SET activa = FALSE WHERE nombre = 'Finca La Esperanza';
SELECT nombre, activa FROM Fincas;

-- 3) borrar las Cataciones del lote de Prueba (DELETE cruzando tablas,
--    filtrando por codigoLote, no por id) — MySQL: DELETE...JOIN
DELETE c
FROM Cataciones c
JOIN Lotes l ON l.idLote = c.loteId
WHERE l.codigoLote = 'TEST-0000';

SELECT * FROM Cataciones c JOIN Lotes l ON l.idLote=c.loteId WHERE l.codigoLote='TEST-0000';

-- 4) vaciar y luego eliminar LotesEspecialidad
TRUNCATE TABLE LotesEspecialidad;
DROP TABLE LotesEspecialidad;

-- Reflexion: DELETE borra filas una por una, dispara triggers, respeta
-- las FK y se puede revertir con ROLLBACK dentro de una transaccion: es
-- DML. TRUNCATE vacia la tabla completa de un golpe, no dispara
-- triggers de fila, reinicia el autoincremental y provoca un commit
-- implicito (es DDL). DROP TABLE elimina la tabla entera con su
-- estructura: tambien es DDL.

-- =========================================================================
-- RETO 9. El pedido que no puede quedar a medias (transacciones) — 10 pts
-- =========================================================================

-- 1) kilos disponibles por tostion
ALTER TABLE Tostiones ADD COLUMN kilosDisponibles DECIMAL(10,2) NOT NULL DEFAULT 0;
ALTER TABLE Tostiones
    ADD CONSTRAINT chk_tostion_disponible CHECK (kilosDisponibles >= 0);

-- inicializar: lo que salio de la tostion menos lo ya vendido en LineasPedido
UPDATE Tostiones t
SET kilosDisponibles = t.kilosSalida - (
    SELECT COALESCE(SUM(lp.kilos), 0) FROM LineasPedido lp WHERE lp.tostionId = t.idTostion
);

SELECT idTostion, kilosSalida, kilosDisponibles FROM Tostiones;

-- 2) transaccion: nuevo pedido de 2 lineas que descuenta inventario
-- (de nuevo: subconsultas por clave natural en vez de @variables, para
-- que funcione sin importar la sesion/orden de ejecucion en el cliente)
START TRANSACTION;
    INSERT INTO Pedidos (clienteId, fechaPedido, estado)
    VALUES ((SELECT idCliente FROM Clientes WHERE nombre='Nordic Roasters AB'), '2026-03-28', 'pendiente');

    INSERT INTO LineasPedido (pedidoId, tostionId, kilos, precioKg) VALUES (
        (SELECT idPedido FROM Pedidos WHERE clienteId=(SELECT idCliente FROM Clientes WHERE nombre='Nordic Roasters AB') AND fechaPedido='2026-03-28'),
        (SELECT idTostion FROM Tostiones WHERE loteId=(SELECT idLote FROM Lotes WHERE codigoLote='HUI-2026-014')), 20.00, 28500.00);
    UPDATE Tostiones SET kilosDisponibles = kilosDisponibles - 20.00
        WHERE loteId = (SELECT idLote FROM Lotes WHERE codigoLote='HUI-2026-014');

    INSERT INTO LineasPedido (pedidoId, tostionId, kilos, precioKg) VALUES (
        (SELECT idPedido FROM Pedidos WHERE clienteId=(SELECT idCliente FROM Clientes WHERE nombre='Nordic Roasters AB') AND fechaPedido='2026-03-28'),
        (SELECT idTostion FROM Tostiones WHERE loteId=(SELECT idLote FROM Lotes WHERE codigoLote='QUI-2026-021')), 15.00, 66000.00);
    UPDATE Tostiones SET kilosDisponibles = kilosDisponibles - 15.00
        WHERE loteId = (SELECT idLote FROM Lotes WHERE codigoLote='QUI-2026-021');
COMMIT;

SELECT t.idTostion, t.kilosDisponibles, l.codigoLote
FROM Tostiones t JOIN Lotes l ON l.idLote = t.loteId
WHERE l.codigoLote IN ('HUI-2026-014','QUI-2026-021');

-- 3) simular el desastre: pedir mas kilos de los disponibles
START TRANSACTION;
    INSERT INTO Pedidos (clienteId, fechaPedido, estado)
    VALUES ((SELECT idCliente FROM Clientes WHERE nombre='Nordic Roasters AB'), '2026-03-29', 'pendiente');

    INSERT INTO LineasPedido (pedidoId, tostionId, kilos, precioKg) VALUES (
        (SELECT idPedido FROM Pedidos WHERE clienteId=(SELECT idCliente FROM Clientes WHERE nombre='Nordic Roasters AB') AND fechaPedido='2026-03-29'),
        (SELECT idTostion FROM Tostiones WHERE loteId=(SELECT idLote FROM Lotes WHERE codigoLote='QUI-2026-021')), 1000.00, 66000.00);
    -- el saldo de esa tostion no alcanza para 1000 kg:
    UPDATE Tostiones SET kilosDisponibles = kilosDisponibles - 1000.00
        WHERE loteId = (SELECT idLote FROM Lotes WHERE codigoLote='QUI-2026-021');
    -- Error esperado:
    -- ERROR 4025 (23000): CONSTRAINT `chk_tostion_disponible` failed for `trazacafe`.`Tostiones`
ROLLBACK;

-- Prueba de que no quedo ni la cabecera:
SELECT * FROM Pedidos WHERE fechaPedido = '2026-03-29';  -- 0 filas

-- 4) SAVEPOINT: deshacer solo la segunda linea, confirmar la primera
START TRANSACTION;
    INSERT INTO Pedidos (clienteId, fechaPedido, estado)
    VALUES ((SELECT idCliente FROM Clientes WHERE nombre='Café Bogotá Selecto S.A.S.'), '2026-03-30', 'pendiente');

    INSERT INTO LineasPedido (pedidoId, tostionId, kilos, precioKg) VALUES (
        (SELECT idPedido FROM Pedidos WHERE clienteId=(SELECT idCliente FROM Clientes WHERE nombre='Café Bogotá Selecto S.A.S.') AND fechaPedido='2026-03-30'),
        (SELECT idTostion FROM Tostiones WHERE loteId=(SELECT idLote FROM Lotes WHERE codigoLote='HUI-2026-015')), 10.00, 27000.00);
    UPDATE Tostiones SET kilosDisponibles = kilosDisponibles - 10.00
        WHERE loteId = (SELECT idLote FROM Lotes WHERE codigoLote='HUI-2026-015');

    SAVEPOINT antes_linea_2;

    INSERT INTO LineasPedido (pedidoId, tostionId, kilos, precioKg) VALUES (
        (SELECT idPedido FROM Pedidos WHERE clienteId=(SELECT idCliente FROM Clientes WHERE nombre='Café Bogotá Selecto S.A.S.') AND fechaPedido='2026-03-30'),
        (SELECT idTostion FROM Tostiones WHERE loteId=(SELECT idLote FROM Lotes WHERE codigoLote='HUI-2026-015')), 99999.00, 27000.00);
    UPDATE Tostiones SET kilosDisponibles = kilosDisponibles - 99999.00
        WHERE loteId = (SELECT idLote FROM Lotes WHERE codigoLote='HUI-2026-015');
    -- esto viola el CHECK; deshacemos solo hasta el SAVEPOINT
    ROLLBACK TO SAVEPOINT antes_linea_2;
COMMIT;

SELECT lp.* FROM LineasPedido lp
JOIN Pedidos p ON p.idPedido = lp.pedidoId
JOIN Clientes c ON c.idCliente = p.clienteId
WHERE c.nombre='Café Bogotá Selecto S.A.S.' AND p.fechaPedido='2026-03-30';  -- solo 1 linea

-- 5) experimento comparativo: DDL dentro de una transaccion + ROLLBACK
START TRANSACTION;
    CREATE TABLE Prueba (id INT);
ROLLBACK;

SHOW TABLES LIKE 'Prueba';
-- En MySQL la tabla SI existe despues del ROLLBACK (ver reflexion).
DROP TABLE IF EXISTS Prueba;  -- limpieza

-- Reflexion: en PostgreSQL el CREATE TABLE queda deshecho por el
-- ROLLBACK porque el DDL es transaccional. En MySQL, CREATE TABLE
-- provoca un COMMIT implicito antes de ejecutarse, asi que la tabla
-- "Prueba" sigue existiendo despues del ROLLBACK. El riesgo para un
-- script de migracion en MySQL es que mezclar DDL y DML en la misma
-- transaccion rompe la atomicidad: si algo falla despues del CREATE
-- TABLE, ese cambio de estructura NO se revierte aunque el resto si,
-- dejando la base en un estado intermedio e inconsistente.

-- =========================================================================
-- RETO 10. El QR que cuenta la historia (VISTA) — 10 pts
-- =========================================================================
DROP VIEW IF EXISTS Trazabilidad;

CREATE OR REPLACE VIEW Trazabilidad AS
SELECT
    c.nombre                                   AS cliente,
    c.pais                                     AS paisCliente,
    f.nombre                                   AS finca,
    f.caficultor                               AS caficultor,
    f.municipio                                AS municipio,
    f.altitudM                                AS altitudM,
    l.variedad                                 AS variedad,
    l.proceso                                  AS proceso,
    sca.puntajePromedio                       AS puntajeScaPromedio,
    t.fechaTostion                            AS fechaTostion,
    t.perfil                                   AS perfilTostion,
    -- Dato creativo: certificaciones vigentes de la finca, para que el
    -- consumidor sepa si el cafe es organico y/o de comercio justo.
    certs.listaCertificaciones                AS certificaciones,
    CONCAT(
        l.variedad, ' ', l.proceso, ' de ', f.nombre, ', ', f.municipio,
        ' (', f.altitudM, ' m). Puntaje ', sca.puntajePromedio,
        '. Tostado ', t.perfil, ' el ', t.fechaTostion,
        IF(certs.listaCertificaciones IS NOT NULL,
           CONCAT('. Certificado: ', certs.listaCertificaciones, '.'), '.')
    ) AS textoQr
FROM LineasPedido lp
JOIN Pedidos   p  ON p.idPedido = lp.pedidoId
JOIN Clientes  c  ON c.idCliente = p.clienteId
JOIN Tostiones t  ON t.idTostion = lp.tostionId
JOIN Lotes     l  ON l.idLote = t.loteId
JOIN Fincas    f  ON f.idFinca = l.fincaId
LEFT JOIN (
    SELECT loteId, ROUND(AVG(puntajeSca), 2) AS puntajePromedio
    FROM Cataciones
    GROUP BY loteId
) sca ON sca.loteId = l.idLote
LEFT JOIN (
    SELECT fc.fincaId, GROUP_CONCAT(cert.nombre SEPARATOR ' + ') AS listaCertificaciones
    FROM FincaCertificacion fc
    JOIN Certificaciones cert ON cert.idCertificacion = fc.certificacionId
    GROUP BY fc.fincaId
) certs ON certs.fincaId = f.idFinca;

-- Consulta filtrando un solo pedido, como lo haria la app
SELECT * FROM Trazabilidad WHERE cliente = 'Röstwerk Berlin GmbH';

-- Reflexion: una vista NO guarda datos propios: es una consulta
-- guardada que se ejecuta cada vez que se consulta, asi que siempre
-- refleja el estado actual de las tablas base. La ventaja frente a
-- LotesEspecialidad (reto 5) es que nunca queda desactualizada ni
-- ocupa espacio de almacenamiento adicional; la desventaja es que si
-- la consulta es pesada, se recalcula cada vez que se invoca (para eso
-- existen las vistas materializadas).
